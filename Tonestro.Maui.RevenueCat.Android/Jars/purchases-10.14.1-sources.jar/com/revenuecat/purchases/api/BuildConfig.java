/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.revenuecat.purchases.api;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.revenuecat.purchases.api";
  public static final String BUILD_TYPE = "release";
  public static final String FLAVOR = "defaults";
  // Field from default config.
  public static final String BILLING_CLIENT_VERSION = "8.3.0";
  // Field from default config.
  public static final boolean ENABLE_EXTRA_REQUEST_LOGGING = false;
}
