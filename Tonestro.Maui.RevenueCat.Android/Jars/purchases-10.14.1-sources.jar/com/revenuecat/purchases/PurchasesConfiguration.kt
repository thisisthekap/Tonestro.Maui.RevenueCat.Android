package com.revenuecat.purchases

import android.content.Context
import com.revenuecat.purchases.common.isDeviceProtectedStorageCompat
import com.revenuecat.purchases.galaxy.GalaxyBillingMode
import java.util.concurrent.ExecutorService

/**
 * Holds parameters to initialize the SDK. Create an instance of this class using the [Builder] and pass it to
 * [Purchases.configure].
 */
public open class PurchasesConfiguration(builder: Builder) {

    public val context: Context
    public val apiKey: String
    public val appUserID: String?

    @Deprecated(
        "observerMode is being deprecated in favor of purchasesAreCompletedBy.",
        ReplaceWith(
            "purchasesAreCompletedBy == MY_APP",
            "com.revenuecat.purchases.PurchasesAreCompletedBy.MY_APP",
        ),
    )
    public val observerMode: Boolean
        get() = when (purchasesAreCompletedBy) {
            PurchasesAreCompletedBy.REVENUECAT -> false
            PurchasesAreCompletedBy.MY_APP -> true
        }
    public val purchasesAreCompletedBy: PurchasesAreCompletedBy
    public val showInAppMessagesAutomatically: Boolean
    public val service: ExecutorService?
    public val store: Store
    public val diagnosticsEnabled: Boolean
    public val dangerousSettings: DangerousSettings
    public val verificationMode: EntitlementVerificationMode
    public val pendingTransactionsForPrepaidPlansEnabled: Boolean
    public val automaticDeviceIdentifierCollectionEnabled: Boolean
    public val preferredUILocaleOverride: String?

    public val galaxyBillingMode: GalaxyBillingMode

    @get:JvmSynthetic
    internal val iamEnabled: Boolean

    init {
        this.context =
            if (builder.context.isDeviceProtectedStorageCompat) {
                builder.context
            } else {
                builder.context.applicationContext
            }
        this.apiKey = builder.apiKey.trim()
        this.appUserID = builder.appUserID
        this.purchasesAreCompletedBy = builder.purchasesAreCompletedBy
        this.service = builder.service
        this.store = builder.store
        this.diagnosticsEnabled = builder.diagnosticsEnabled
        this.verificationMode = builder.verificationMode
        this.dangerousSettings = builder.dangerousSettings
        this.showInAppMessagesAutomatically = builder.showInAppMessagesAutomatically
        this.pendingTransactionsForPrepaidPlansEnabled = builder.pendingTransactionsForPrepaidPlansEnabled
        this.automaticDeviceIdentifierCollectionEnabled =
            builder.automaticDeviceIdentifierCollectionEnabled
        this.preferredUILocaleOverride = builder.preferredUILocaleOverride

        this.galaxyBillingMode = builder.galaxyBillingMode
        this.iamEnabled = builder.iamEnabled
    }

    @OptIn(InternalRevenueCatAPI::class)
    internal fun copy(
        appUserID: String? = this.appUserID,
        service: ExecutorService? = this.service,
    ): PurchasesConfiguration {
        var builder = Builder(context, apiKey)
            .appUserID(appUserID)
            .purchasesAreCompletedBy(purchasesAreCompletedBy)
            .store(store)
            .diagnosticsEnabled(diagnosticsEnabled)
            .entitlementVerificationMode(verificationMode)
            .dangerousSettings(dangerousSettings)
            .showInAppMessagesAutomatically(showInAppMessagesAutomatically)
            .pendingTransactionsForPrepaidPlansEnabled(pendingTransactionsForPrepaidPlansEnabled)
            .automaticDeviceIdentifierCollectionEnabled(
                automaticDeviceIdentifierCollectionEnabled,
            )
            .preferredUILocaleOverride(preferredUILocaleOverride)
            .galaxyBillingMode(galaxyBillingMode)
            .iamEnabled(iamEnabled)
        if (service != null) {
            builder = builder.service(service)
        }
        return builder.build()
    }

    @SuppressWarnings("TooManyFunctions")
    public open class Builder(
        @get:JvmSynthetic internal val context: Context,
        @get:JvmSynthetic internal val apiKey: String,
    ) {

        @set:JvmSynthetic @get:JvmSynthetic
        internal var appUserID: String? = null

        @set:JvmSynthetic @get:JvmSynthetic
        internal var purchasesAreCompletedBy: PurchasesAreCompletedBy = PurchasesAreCompletedBy.REVENUECAT

        @set:JvmSynthetic @get:JvmSynthetic
        internal var showInAppMessagesAutomatically: Boolean = true

        @set:JvmSynthetic @get:JvmSynthetic
        internal var service: ExecutorService? = null

        @set:JvmSynthetic @get:JvmSynthetic
        internal var store: Store = Store.PLAY_STORE

        @set:JvmSynthetic @get:JvmSynthetic
        internal var diagnosticsEnabled: Boolean = false

        @set:JvmSynthetic @get:JvmSynthetic
        internal var verificationMode: EntitlementVerificationMode = EntitlementVerificationMode.default

        @set:JvmSynthetic @get:JvmSynthetic
        internal var dangerousSettings: DangerousSettings = DangerousSettings()

        @set:JvmSynthetic @get:JvmSynthetic
        internal var pendingTransactionsForPrepaidPlansEnabled: Boolean = false

        @set:JvmSynthetic @get:JvmSynthetic
        internal var automaticDeviceIdentifierCollectionEnabled: Boolean = true

        @set:JvmSynthetic @get:JvmSynthetic
        internal var preferredUILocaleOverride: String? = null

        @set:JvmSynthetic
        @get:JvmSynthetic
        internal var galaxyBillingMode: GalaxyBillingMode = GalaxyBillingMode.PRODUCTION

        @set:JvmSynthetic @get:JvmSynthetic
        internal var iamEnabled: Boolean = false

        /**
         * A unique id for identifying the user
         */
        public fun appUserID(appUserID: String?): Builder = apply {
            this.appUserID = appUserID
        }

        /**
         * Enable this setting to show in-app messages from Google Play automatically. Default is enabled.
         * For more info: https://rev.cat/googleplayinappmessaging
         *
         * If this setting is disabled, you can show the snackbar by calling
         * [Purchases.showInAppMessagesIfNeeded]
         */
        public fun showInAppMessagesAutomatically(showInAppMessagesAutomatically: Boolean): Builder = apply {
            this.showInAppMessagesAutomatically = showInAppMessagesAutomatically
        }

        /**
         * An optional boolean. Set this to TRUE if you have your own IAP implementation and
         * want to use only RevenueCat's backend. Default is FALSE. If you are on Android and setting this to TRUE,
         * you will have to acknowledge the purchases yourself.
         */
        @Deprecated(
            "observerMode() is being deprecated in favor of purchasesAreCompletedBy().",
            ReplaceWith(
                "purchasesAreCompletedBy(if (observerMode) MY_APP else REVENUECAT)",
                "com.revenuecat.purchases.PurchasesAreCompletedBy.REVENUECAT",
                "com.revenuecat.purchases.PurchasesAreCompletedBy.MY_APP",
            ),
        )
        public fun observerMode(observerMode: Boolean): Builder = apply {
            purchasesAreCompletedBy(
                if (observerMode) {
                    PurchasesAreCompletedBy.MY_APP
                } else {
                    PurchasesAreCompletedBy.REVENUECAT
                },
            )
        }

        /**
         * An optional setting. Set this to [MY_APP][PurchasesAreCompletedBy.MY_APP] if you have your own IAP
         * implementation and want to use only RevenueCat's backend. Default is
         * [REVENUECAT][PurchasesAreCompletedBy.REVENUECAT]. If you are on Android and setting this to
         * [MY_APP][PurchasesAreCompletedBy.MY_APP], you will have to acknowledge the purchases yourself.
         *
         * **Note:** failing to acknowledge a purchase within 3 days will lead to Google Play automatically issuing a
         * refund to the user.
         *
         * For more info, see
         * [revenuecat.com](https://www.revenuecat.com/docs/migrating-to-revenuecat/sdk-or-not/finishing-transactions)
         * and [developer.android.com](https://developer.android.com/google/play/billing/integrate#process).
         */
        public fun purchasesAreCompletedBy(purchasesAreCompletedBy: PurchasesAreCompletedBy): Builder = apply {
            this.purchasesAreCompletedBy = purchasesAreCompletedBy
        }

        /**
         * Executor service for performing backend operations. This can be used if you want to share an executor between
         * Purchases and your own code. If not passed in, one will be created.
         */
        public fun service(service: ExecutorService): Builder = apply {
            this.service = service
        }

        /**
         * The store in which to make purchases. See [Store] for supported stores.
         * @see Store
         */
        public fun store(store: Store): Builder = apply {
            this.store = store
        }

        /**
         * Enabling diagnostics will send some performance and debugging information from the SDK to our servers.
         * Examples of this information include response times, cache hits or error codes.
         * No personal identifiable information will be collected.
         * The default value is false.
         */
        public fun diagnosticsEnabled(diagnosticsEnabled: Boolean): Builder = apply {
            this.diagnosticsEnabled = diagnosticsEnabled
        }

        /**
         * Deprecated. Use [entitlementVerificationMode] instead.
         *
         * Enables signature verification of requests to the RevenueCat backend
         * and enables diagnostics reports to RevenueCat to help us analyze this feature.
         *
         * When changing from disabled to enabled, the SDK will clear the CustomerInfo cache.
         * This means users will need to connect to the internet to get their entitlements back.
         *
         * The result of the verification can be obtained from [EntitlementInfos.verification] or
         * [EntitlementInfo.verification].
         *
         * Default mode is disabled.
         *
         * @warning This function is marked as [ExperimentalPreviewRevenueCatPurchasesAPI] and may change in the future.
         */
        @Deprecated(
            "Use the new entitlementVerificationMode setter instead.",
            ReplaceWith("entitlementVerificationMode(EntitlementVerificationMode.INFORMATIONAL)"),
        )
        @JvmSynthetic
        @ExperimentalPreviewRevenueCatPurchasesAPI
        public fun informationalVerificationModeAndDiagnosticsEnabled(enabled: Boolean): Builder = apply {
            if (enabled) {
                this.verificationMode = EntitlementVerificationMode.INFORMATIONAL
                this.diagnosticsEnabled = true
            } else {
                this.verificationMode = EntitlementVerificationMode.DISABLED
                this.diagnosticsEnabled = false
            }
        }

        /**
         * Sets the [EntitlementVerificationMode] to perform signature verification of requests to the
         * RevenueCat backend.
         *
         * When changing from [EntitlementVerificationMode.DISABLED] to other modes, the SDK will clear the
         * CustomerInfo cache.
         * This means users will need to connect to the internet to get their entitlements back.
         *
         * The result of the verification can be obtained from [EntitlementInfos.verification] or
         * [EntitlementInfo.verification].
         *
         * Default mode is disabled. Please see https://rev.cat/trusted-entitlements for more info.
         */
        public fun entitlementVerificationMode(verificationMode: EntitlementVerificationMode): Builder = apply {
            this.verificationMode = verificationMode
        }

        /**
         * Only use a Dangerous Setting if suggested by RevenueCat support team.
         */
        public fun dangerousSettings(dangerousSettings: DangerousSettings): Builder = apply {
            this.dangerousSettings = dangerousSettings
        }

        /**
         * Enable this setting if you want to allow pending purchases for prepaid subscriptions (only supported
         * in Google Play). Note that entitlements are not granted until payment is done.
         * Default is disabled.
         */
        public fun pendingTransactionsForPrepaidPlansEnabled(
            pendingTransactionsForPrepaidPlansEnabled: Boolean,
        ): Builder = apply {
            this.pendingTransactionsForPrepaidPlansEnabled = pendingTransactionsForPrepaidPlansEnabled
        }

        /**
         * Enable this setting to allow the collection of identifiers when setting the identifier for an
         * attribution network. For example, when calling [Purchases.setAdjustID] or [Purchases.setAppsflyerID],
         * the SDK would collect the Android advertising ID, IP and device versions, if available, and send them
         * to RevenueCat. This is required by some attribution networks to attribute installs and re-installs.
         *
         * Enabling this setting does NOT mean we will always collect the identifiers. We will only do so when
         * setting an attribution network ID AND the user has not limited ad tracking on their device.
         *
         * Default is enabled.
         */
        public fun automaticDeviceIdentifierCollectionEnabled(
            automaticDeviceIdentifierCollectionEnabled: Boolean,
        ): Builder = apply {
            this.automaticDeviceIdentifierCollectionEnabled = automaticDeviceIdentifierCollectionEnabled
        }

        /**
         * Sets the preferred UI locale for RevenueCat UI components like Paywalls and Customer Center.
         * This allows you to override the system locale and display the UI in a specific language.
         *
         * @param localeString The locale string in the format "language_COUNTRY" (e.g., "en_US", "es_ES", "de_DE").
         *                     Pass null to use the system default locale.
         *
         * **Note:** This only affects UI components from the RevenueCatUI module and requires
         * importing RevenueCatUI in your project.
         */
        public fun preferredUILocaleOverride(localeString: String?): Builder = apply {
            this.preferredUILocaleOverride = localeString
        }

        /**
         * The billing mode used by the Galaxy Store. Only applicable if using the Galaxy Store.
         * @see GalaxyBillingMode
         */
        public fun galaxyBillingMode(galaxyBillingMode: GalaxyBillingMode): Builder = apply {
            this.galaxyBillingMode = galaxyBillingMode
        }

        /**
         * Enabling this instructs the SDK to prefer using token-based user sessions
         * for communicating with the server. Default is disabled.
         */
        @InternalRevenueCatAPI
        public fun iamEnabled(iamEnabled: Boolean): Builder = apply {
            this.iamEnabled = iamEnabled
        }

        /**
         * Creates a [PurchasesConfiguration] instance with the specified properties.
         */
        public open fun build(): PurchasesConfiguration {
            return PurchasesConfiguration(this)
        }
    }

    @Suppress("CyclomaticComplexMethod")
    public override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as PurchasesConfiguration

        if (apiKey != other.apiKey) return false
        if (appUserID != other.appUserID) return false
        if (purchasesAreCompletedBy != other.purchasesAreCompletedBy) return false
        if (showInAppMessagesAutomatically != other.showInAppMessagesAutomatically) return false
        if (store != other.store) return false
        if (diagnosticsEnabled != other.diagnosticsEnabled) return false
        if (dangerousSettings != other.dangerousSettings) return false
        if (verificationMode != other.verificationMode) return false
        if (pendingTransactionsForPrepaidPlansEnabled != other.pendingTransactionsForPrepaidPlansEnabled) return false
        if (automaticDeviceIdentifierCollectionEnabled != other.automaticDeviceIdentifierCollectionEnabled) return false
        if (preferredUILocaleOverride != other.preferredUILocaleOverride) return false
        if (galaxyBillingMode != other.galaxyBillingMode) return false
        if (iamEnabled != other.iamEnabled) return false

        return true
    }

    public override fun hashCode(): Int {
        var result = apiKey.hashCode()
        result = 31 * result + (appUserID?.hashCode() ?: 0)
        result = 31 * result + purchasesAreCompletedBy.hashCode()
        result = 31 * result + showInAppMessagesAutomatically.hashCode()
        result = 31 * result + store.hashCode()
        result = 31 * result + diagnosticsEnabled.hashCode()
        result = 31 * result + dangerousSettings.hashCode()
        result = 31 * result + verificationMode.hashCode()
        result = 31 * result + pendingTransactionsForPrepaidPlansEnabled.hashCode()
        result = 31 * result + automaticDeviceIdentifierCollectionEnabled.hashCode()
        result = 31 * result + (preferredUILocaleOverride?.hashCode() ?: 0)
        result = 31 * result + (galaxyBillingMode.hashCode())
        result = 31 * result + iamEnabled.hashCode()
        return result
    }
}
