package com.revenuecat.purchases.identity

import com.revenuecat.purchases.CustomerInfo
import com.revenuecat.purchases.InternalRevenueCatAPI
import com.revenuecat.purchases.PurchasesError
import com.revenuecat.purchases.PurchasesErrorCode
import com.revenuecat.purchases.PurchasesException
import com.revenuecat.purchases.VerificationResult
import com.revenuecat.purchases.common.Backend
import com.revenuecat.purchases.common.Delay
import com.revenuecat.purchases.common.Dispatcher
import com.revenuecat.purchases.common.LogIntent
import com.revenuecat.purchases.common.caching.DeviceCache
import com.revenuecat.purchases.common.debugLog
import com.revenuecat.purchases.common.errorLog
import com.revenuecat.purchases.common.infoLog
import com.revenuecat.purchases.common.log
import com.revenuecat.purchases.common.offerings.OfferingsCache
import com.revenuecat.purchases.common.offlineentitlements.OfflineEntitlementsManager
import com.revenuecat.purchases.common.remoteconfig.RemoteConfigManager
import com.revenuecat.purchases.common.safeResume
import com.revenuecat.purchases.common.safeResumeWithException
import com.revenuecat.purchases.common.verification.SignatureVerificationMode
import com.revenuecat.purchases.strings.IdentityStrings
import com.revenuecat.purchases.subscriberattributes.SubscriberAttributesManager
import com.revenuecat.purchases.subscriberattributes.caching.SubscriberAttributesCache
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.UUID

@OptIn(InternalRevenueCatAPI::class)
@Suppress("TooManyFunctions", "LongParameterList")
internal class IdentityManager(
    private val deviceCache: DeviceCache,
    private val subscriberAttributesCache: SubscriberAttributesCache,
    private val subscriberAttributesManager: SubscriberAttributesManager,
    private val offeringsCache: OfferingsCache,
    private val remoteConfigManager: RemoteConfigManager?,
    private val backend: Backend,
    private val offlineEntitlementsManager: OfflineEntitlementsManager,
    private val dispatcher: Dispatcher,
    private val uiPreviewMode: Boolean = false,
) {
    companion object {
        private val anonymousIdRegex = "^\\\$RCAnonymousID:([a-f0-9]{32})$".toRegex()
        internal const val UI_PREVIEW_MODE_APP_USER_ID = "\$RC_PREVIEW_MODE_USER"

        fun isUserIDAnonymous(appUserID: String): Boolean {
            return anonymousIdRegex.matches(appUserID)
        }
    }

    val currentAppUserID: String
        get() = deviceCache.getCachedAppUserID() ?: ""

    // region Public functions

    @Synchronized
    fun configure(
        appUserID: String?,
    ) {
        val appUserIDToUse = when {
            uiPreviewMode -> {
                log(LogIntent.USER) { IdentityStrings.CONFIGURING_WITH_PREVIEW_MODE_USER_ID }
                UI_PREVIEW_MODE_APP_USER_ID
            }
            appUserID.isNullOrBlank() -> {
                if (appUserID?.isBlank() == true) {
                    log(LogIntent.WARNING) { IdentityStrings.EMPTY_APP_USER_ID_WILL_BECOME_ANONYMOUS }
                }
                deviceCache.getCachedAppUserID()
                    ?: deviceCache.getLegacyCachedAppUserID()
                    ?: generateRandomID()
            }
            else -> appUserID
        }
        log(LogIntent.USER) { IdentityStrings.IDENTIFYING_APP_USER_ID.format(appUserIDToUse) }

        val cacheEditor = deviceCache.startEditing()
        deviceCache.cacheAppUserID(appUserIDToUse, cacheEditor)
        subscriberAttributesCache.cleanUpSubscriberAttributeCache(appUserIDToUse, cacheEditor)
        invalidateETagCacheIfNeeded(appUserIDToUse)
        cacheEditor.apply()

        enqueue {
            deviceCache.cleanupOldAttributionData()
        }
    }

    suspend fun aliasCurrentUserIdTo(
        oldAppUserID: String,
    ) {
        val newAppUserID = currentAppUserID
        return suspendCancellableCoroutine { continuation ->
            backend.aliasUsers(
                oldAppUserID = oldAppUserID,
                newAppUserID = newAppUserID,
                onSuccessHandler = {
                    // Cache wipe runs unconditionally: the backend alias has already committed
                    // server-side, so local caches must be cleared to stay consistent even if
                    // the caller cancelled mid-flight. safeResume then no-ops if cancelled.
                    synchronized(this@IdentityManager) {
                        log(LogIntent.USER) {
                            IdentityStrings.ALIAS_OLD_USER_ID_TO_CURRENT_SUCCESSFUL.format(oldAppUserID, newAppUserID)
                        }
                        clearRemoteConfigThenOfferingsCaches(newAppUserID)
                        deviceCache.clearCustomerInfoCache(newAppUserID)
                        offlineEntitlementsManager.resetOfflineCustomerInfoCache()
                    }
                    continuation.safeResume(Unit)
                },
                onErrorHandler = { error ->
                    continuation.safeResumeWithException(PurchasesException(error))
                },
            )
        }
    }

    fun logIn(
        newAppUserID: String,
        onSuccess: (CustomerInfo, Boolean) -> Unit,
        onError: (PurchasesError) -> Unit,
    ) {
        if (currentAppUserID == UI_PREVIEW_MODE_APP_USER_ID ||
            newAppUserID == UI_PREVIEW_MODE_APP_USER_ID
        ) {
            onError(
                PurchasesError(
                    PurchasesErrorCode.UnsupportedError,
                    IdentityStrings.OPERATION_NOT_SUPPORTED_IN_PREVIEW_MODE,
                ).also { errorLog(it) },
            )
            return
        }

        if (newAppUserID.isBlank()) {
            onError(
                PurchasesError(
                    PurchasesErrorCode.InvalidAppUserIdError,
                    IdentityStrings.LOG_IN_ERROR_MISSING_APP_USER_ID,
                ).also { errorLog(it) },
            )
            return
        }

        log(LogIntent.USER) { IdentityStrings.LOGGING_IN.format(currentAppUserID, newAppUserID) }
        val oldAppUserID = currentAppUserID
        subscriberAttributesManager.synchronizeSubscriberAttributesForAllUsers(newAppUserID) {
            backend.logIn(
                oldAppUserID,
                newAppUserID,
                { customerInfo, created ->
                    synchronized(this@IdentityManager) {
                        log(LogIntent.USER) {
                            IdentityStrings.LOG_IN_SUCCESSFUL.format(newAppUserID, created)
                        }
                        deviceCache.clearCachesForAppUserID(oldAppUserID)
                        clearRemoteConfigThenOfferingsCaches(newAppUserID)
                        subscriberAttributesCache.clearSubscriberAttributesIfSyncedForSubscriber(oldAppUserID)

                        deviceCache.cacheAppUserID(newAppUserID)
                        deviceCache.cacheCustomerInfo(newAppUserID, customerInfo)
                        copySubscriberAttributesToNewUserIfOldIsAnonymous(oldAppUserID, newAppUserID)
                        offlineEntitlementsManager.resetOfflineCustomerInfoCache()
                    }
                    onSuccess(customerInfo, created)
                },
                onError,
            )
        }
    }

    fun switchUser(newAppUserID: String) {
        if (currentAppUserID == UI_PREVIEW_MODE_APP_USER_ID ||
            newAppUserID == UI_PREVIEW_MODE_APP_USER_ID
        ) {
            errorLog(
                PurchasesError(
                    PurchasesErrorCode.UnsupportedError,
                    IdentityStrings.OPERATION_NOT_SUPPORTED_IN_PREVIEW_MODE,
                ),
            )
            return
        }
        debugLog { IdentityStrings.SWITCHING_USER.format(newAppUserID) }
        resetAndSaveUserID(newAppUserID)
    }

    @Synchronized
    fun logOut(completion: ((PurchasesError?) -> Unit)) {
        if (currentAppUserID == UI_PREVIEW_MODE_APP_USER_ID) {
            completion(
                PurchasesError(
                    PurchasesErrorCode.UnsupportedError,
                    IdentityStrings.OPERATION_NOT_SUPPORTED_IN_PREVIEW_MODE,
                ).also { errorLog(it) },
            )
            return
        }
        if (currentUserIsAnonymous()) {
            log(LogIntent.RC_ERROR) { IdentityStrings.LOG_OUT_CALLED_ON_ANONYMOUS_USER }
            completion(PurchasesError(PurchasesErrorCode.LogOutWithAnonymousUserError))
            return
        }
        subscriberAttributesManager.synchronizeSubscriberAttributesForAllUsers(currentAppUserID) {
            resetAndSaveUserID(generateRandomID())
            log(LogIntent.USER) { IdentityStrings.LOG_OUT_SUCCESSFUL }
            completion(null)
        }
    }

    @Synchronized
    fun currentUserIsAnonymous(): Boolean {
        val currentAppUserIDLooksAnonymous = isUserIDAnonymous(deviceCache.getCachedAppUserID() ?: "")
        val isLegacyAnonymousAppUserID =
            deviceCache.getCachedAppUserID() == deviceCache.getLegacyCachedAppUserID()
        return currentAppUserIDLooksAnonymous || isLegacyAnonymousAppUserID
    }

    // endregion

    // region Private functions

    /**
     * Clears the remote-config caches and then the offerings cache on an identity change, always in this
     * order. The order is load-bearing: [remoteConfigManager]'s clearCache synchronously invalidates the
     * in-memory workflow / ui_config caches, whereas clearing the offerings cache makes the current offering
     * null. If offerings were cleared first, a concurrent getOfferings / paywall present in the gap would see
     * no current offering (so WorkflowsConfigProvider.isWarmForCurrentOffering reports "warm") and the
     * memory-first reads would serve the previous user's per-user config (app_user_id / enrolled_variants).
     * Clearing remote config first drops those caches so no stale read is possible. Callers already hold the
     * [IdentityManager] monitor.
     */
    private fun clearRemoteConfigThenOfferingsCaches(newAppUserID: String) {
        remoteConfigManager?.clearCache(newAppUserID)
        offeringsCache.clearCache()
    }

    private fun copySubscriberAttributesToNewUserIfOldIsAnonymous(oldAppUserId: String, newAppUserId: String) {
        if (isUserIDAnonymous(oldAppUserId)) {
            subscriberAttributesManager.copyUnsyncedSubscriberAttributes(oldAppUserId, newAppUserId)
        }
    }

    private fun invalidateETagCacheIfNeeded(
        appUserID: String,
    ) {
        if (backend.verificationMode == SignatureVerificationMode.Disabled) {
            return
        }
        val cachedCustomerInfo = deviceCache.getCachedCustomerInfo(appUserID)
        if (shouldInvalidateETagCache(cachedCustomerInfo)) {
            infoLog { IdentityStrings.INVALIDATING_CACHED_ETAG_CACHE }
            backend.clearCaches()
        }
    }

    @Suppress("UnusedPrivateMember", "FunctionOnlyReturningConstant")
    private fun shouldInvalidateETagCache(customerInfo: CustomerInfo?): Boolean {
        return customerInfo != null &&
            customerInfo.entitlements.verification == VerificationResult.NOT_REQUESTED &&
            backend.verificationMode != SignatureVerificationMode.Disabled
    }

    private fun generateRandomID(): String {
        return "\$RCAnonymousID:" + UUID.randomUUID().toString().toLowerCase(Locale.ROOT).replace("-", "")
            .also {
                log(LogIntent.USER) { IdentityStrings.SETTING_NEW_ANON_ID }
            }
    }

    @Synchronized
    private fun resetAndSaveUserID(newUserID: String) {
        deviceCache.clearCachesForAppUserID(currentAppUserID)
        clearRemoteConfigThenOfferingsCaches(newUserID)
        subscriberAttributesCache.clearSubscriberAttributesIfSyncedForSubscriber(currentAppUserID)
        offlineEntitlementsManager.resetOfflineCustomerInfoCache()
        deviceCache.cacheAppUserID(newUserID)
        backend.clearCaches()
    }

    @Synchronized
    private fun enqueue(command: () -> Unit) {
        dispatcher.enqueue({ command() }, Delay.NONE)
    }

    // endregion
}
