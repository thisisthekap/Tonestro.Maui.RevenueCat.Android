package com.revenuecat.purchases.common.networking

import android.net.Uri

internal sealed class Endpoint(
    val pathTemplate: String,
    val name: String,
    val fallbackPath: String? = null,
) {
    abstract fun getPath(useFallback: Boolean = false): String

    /**
     * Whether this endpoint returns an RC Container Format response rather than JSON. When
     * `true`, the request advertises `Accept: application/x-rc-format` and the response body is exposed
     * as [HTTPResult.Payload.RCFormat] instead of being decoded as text.
     */
    open val expectsRCFormatResponse: Boolean = false
    data class GetCustomerInfo(val userId: String) : Endpoint("/v1/subscribers/%s", "get_customer") {
        override fun getPath(useFallback: Boolean) = pathTemplate.format(Uri.encode(userId))
    }
    object PostReceipt : Endpoint("/v1/receipts", "post_receipt") {
        override fun getPath(useFallback: Boolean) = pathTemplate
    }
    data class GetOfferings(val userId: String) : Endpoint(
        "/v1/subscribers/%s/offerings",
        "get_offerings",
        fallbackPath = "/v1/offerings",
    ) {
        override fun getPath(useFallback: Boolean): String {
            return if (useFallback && fallbackPath != null) {
                fallbackPath
            } else {
                pathTemplate.format(Uri.encode(userId))
            }
        }
    }

    object LogIn : Endpoint("/v1/subscribers/identify", "log_in") {
        override fun getPath(useFallback: Boolean) = pathTemplate
    }
    data class AliasUsers(val userId: String) : Endpoint("/v1/subscribers/%s/alias", "alias_users") {
        override fun getPath(useFallback: Boolean) = pathTemplate.format(Uri.encode(userId))
    }
    object PostDiagnostics : Endpoint("/v1/diagnostics", "post_diagnostics") {
        override fun getPath(useFallback: Boolean) = pathTemplate
    }
    object PostEvents : Endpoint("/v1/events", "post_paywall_events") {
        override fun getPath(useFallback: Boolean) = pathTemplate
    }
    data class PostAttributes(
        val userId: String,
    ) : Endpoint("/v1/subscribers/%s/attributes", "post_attributes") {
        override fun getPath(useFallback: Boolean) = pathTemplate.format(Uri.encode(userId))
    }
    data class GetAmazonReceipt(
        val userId: String,
        val receiptId: String,
    ) : Endpoint("/v1/receipts/amazon/%s/%s", "get_amazon_receipt") {
        override fun getPath(useFallback: Boolean) = pathTemplate.format(Uri.encode(userId), receiptId)
    }
    object GetProductEntitlementMapping : Endpoint(
        "/v1/product_entitlement_mapping",
        "get_product_entitlement_mapping",
        fallbackPath = "/v1/product_entitlement_mapping",
    ) {
        override fun getPath(useFallback: Boolean): String {
            return if (useFallback && fallbackPath != null) {
                fallbackPath
            } else {
                pathTemplate
            }
        }
    }
    data class GetCustomerCenterConfig(val userId: String) : Endpoint(
        "/v1/customercenter/%s",
        "get_customer_center_config",
    ) {
        override fun getPath(useFallback: Boolean) = pathTemplate.format(Uri.encode(userId))
    }

    data class GetRemoteConfig(val domain: String) : Endpoint(
        pathTemplate = "/v1/config/%s",
        name = "remote_config",
    ) {
        override fun getPath(useFallback: Boolean) = pathTemplate.format(Uri.encode(domain))
        override val expectsRCFormatResponse: Boolean = true
    }

    /**
     * Fallback for [GetRemoteConfig] served from a fallback base URL. Unlike the main endpoint, it is a plain
     * `GET` returning `application/json` (no `x-rc-format`, no inlined blobs, no request body), and its response
     * is signature-verified **without** a nonce (mirroring [GetOfferings]). The domain layer chooses this
     * endpoint explicitly; it does not participate in the generic HTTPClient URL-fallback mechanism.
     */
    data class GetRemoteConfigFallback(val domain: String) : Endpoint(
        pathTemplate = "/v1/config/%s",
        name = "remote_config_fallback",
    ) {
        override fun getPath(useFallback: Boolean) = pathTemplate.format(Uri.encode(domain))
    }
    object PostCreateSupportTicket : Endpoint(
        "/v1/customercenter/support/create-ticket",
        "post_create_support_ticket",
    ) {
        override fun getPath(useFallback: Boolean) = pathTemplate
    }
    object PostRedeemWebPurchase : Endpoint(
        "/v1/subscribers/redeem_purchase",
        "post_redeem_web_purchase",
    ) {
        override fun getPath(useFallback: Boolean) = pathTemplate
    }
    data class GetVirtualCurrencies(val userId: String) : Endpoint(
        pathTemplate = "/v1/subscribers/%s/virtual_currencies",
        name = "get_virtual_currencies",
    ) {
        override fun getPath(useFallback: Boolean) = pathTemplate.format(Uri.encode(userId))
    }
    data class GetRewardVerification(
        val userId: String,
        val clientTransactionId: String,
    ) : Endpoint(
        pathTemplate = "/v1/subscribers/%s/ads/reward_verifications/%s",
        name = "get_reward_verification",
    ) {
        override fun getPath(useFallback: Boolean) =
            pathTemplate.format(Uri.encode(userId), Uri.encode(clientTransactionId))
    }
    data class WebBillingGetProducts(val userId: String, val productIds: Set<String>) : Endpoint(
        pathTemplate = "/rcbilling/v1/subscribers/%s/products?id=%s",
        name = "web_billing_get_products",
    ) {
        override fun getPath(useFallback: Boolean): String {
            return pathTemplate.format(Uri.encode(userId), productIds.joinToString("&id=") { Uri.encode(it) })
        }
    }

    val supportsSignatureVerification: Boolean
        get() = when (this) {
            is GetCustomerInfo,
            LogIn,
            PostReceipt,
            is GetOfferings,
            GetProductEntitlementMapping,
            PostRedeemWebPurchase,
            is GetVirtualCurrencies,
            is GetRewardVerification,
            is GetRemoteConfig,
            is GetRemoteConfigFallback,
            ->
                true
            is GetAmazonReceipt,
            is PostAttributes,
            PostDiagnostics,
            PostEvents,
            is GetCustomerCenterConfig,
            PostCreateSupportTicket,
            is WebBillingGetProducts,
            is AliasUsers,
            ->
                false
        }

    val needsNonceToPerformSigning: Boolean
        get() = when (this) {
            is GetCustomerInfo,
            LogIn,
            PostReceipt,
            PostRedeemWebPurchase,
            is GetVirtualCurrencies,
            is GetRewardVerification,
            is GetRemoteConfig,
            ->
                true
            is GetAmazonReceipt,
            is GetOfferings,
            is PostAttributes,
            PostDiagnostics,
            PostEvents,
            GetProductEntitlementMapping,
            is GetCustomerCenterConfig,
            PostCreateSupportTicket,
            is WebBillingGetProducts,
            is AliasUsers,
            is GetRemoteConfigFallback,
            ->
                false
        }

    val supportsFallbackBaseURLs: Boolean
        get() = fallbackPath != null

    /**
     * Whether this endpoint resolves its base host from the API source provider (the main-API host
     * list, with failover) rather than the app's static base URL. Endpoints hosted elsewhere
     * (diagnostics, events) opt out.
     */
    val usesAPISources: Boolean
        get() = when (this) {
            is GetCustomerInfo,
            LogIn,
            PostReceipt,
            is GetOfferings,
            is AliasUsers,
            is PostAttributes,
            is GetAmazonReceipt,
            GetProductEntitlementMapping,
            is GetCustomerCenterConfig,
            is GetRemoteConfig,
            PostCreateSupportTicket,
            PostRedeemWebPurchase,
            is GetVirtualCurrencies,
            is GetRewardVerification,
            is WebBillingGetProducts,
            ->
                true
            PostDiagnostics,
            PostEvents,
            is GetRemoteConfigFallback,
            ->
                false
        }
}
