//  Purchases
//
//  Copyright © 2019 RevenueCat, Inc. All rights reserved.
//

package com.revenuecat.purchases.common.caching

import android.content.SharedPreferences
import androidx.annotation.VisibleForTesting
import com.revenuecat.purchases.CustomerInfo
import com.revenuecat.purchases.CustomerInfoOriginalSource
import com.revenuecat.purchases.InternalRevenueCatAPI
import com.revenuecat.purchases.VerificationResult
import com.revenuecat.purchases.common.CustomerInfoFactory
import com.revenuecat.purchases.common.DateProvider
import com.revenuecat.purchases.common.DefaultDateProvider
import com.revenuecat.purchases.common.LogIntent
import com.revenuecat.purchases.common.debugLog
import com.revenuecat.purchases.common.errorLog
import com.revenuecat.purchases.common.log
import com.revenuecat.purchases.common.offlineentitlements.ProductEntitlementMapping
import com.revenuecat.purchases.common.sha1
import com.revenuecat.purchases.common.verboseLog
import com.revenuecat.purchases.interfaces.StorefrontProvider
import com.revenuecat.purchases.models.StoreTransaction
import com.revenuecat.purchases.strings.BillingStrings
import com.revenuecat.purchases.strings.OfflineEntitlementsStrings
import com.revenuecat.purchases.strings.ReceiptStrings
import com.revenuecat.purchases.strings.VirtualCurrencyStrings
import com.revenuecat.purchases.utils.optNullableString
import com.revenuecat.purchases.virtualcurrencies.VirtualCurrencies
import com.revenuecat.purchases.virtualcurrencies.VirtualCurrenciesFactory
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerializationException
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json
import org.json.JSONException
import org.json.JSONObject
import java.util.Date
import kotlin.time.Duration.Companion.hours

private val PRODUCT_ENTITLEMENT_MAPPING_CACHE_REFRESH_PERIOD = 25.hours
private const val SHARED_PREFERENCES_PREFIX = "com.revenuecat.purchases."
private val tokenMapSerializer = MapSerializer(String.serializer(), TokenCacheEntry.serializer())
internal const val CUSTOMER_INFO_SCHEMA_VERSION = 3

/**
 * Per-token metadata stored in the unified token cache.
 * Using a data class allows adding more fields in the future without a cache migration.
 */
@Serializable
internal data class TokenCacheEntry(
    val isAutoRenewing: Boolean? = null,
)

@Suppress("TooManyFunctions")
@InternalRevenueCatAPI
public open class DeviceCache(
    private val preferences: SharedPreferences,
    private val apiKey: String,
    private val dateProvider: DateProvider = DefaultDateProvider(),
) : StorefrontProvider {
    private companion object {
        private const val CUSTOMER_INFO_SCHEMA_VERSION_KEY = "schema_version"
        private const val CUSTOMER_INFO_VERIFICATION_RESULT_KEY = "verification_result"
        private const val CUSTOMER_INFO_REQUEST_DATE_KEY = "customer_info_request_date"
        private const val CUSTOMER_INFO_ORIGINAL_SOURCE_KEY = "customer_info_original_source"
    }

    private val apiKeyPrefix: String by lazy { "$SHARED_PREFERENCES_PREFIX$apiKey" }

    @VisibleForTesting
    internal val legacyAppUserIDCacheKey: String by lazy { apiKeyPrefix }

    @VisibleForTesting
    internal val appUserIDCacheKey: String by lazy { "$apiKeyPrefix.new" }
    internal val attributionCacheKey = "$SHARED_PREFERENCES_PREFIX.attribution"

    /**
     * Legacy key that stored sent token hashes as a `Set<String>` via `putStringSet`.
     * Replaced by [tokensCacheKey] which stores a JSON map of `{ hashedToken: isAutoRenewing }`.
     * Kept for migration: on first read, entries are migrated to the new key with `null`
     * auto-renewing values, then this key is deleted.
     */
    internal val legacyTokensCacheKey: String by lazy { "$apiKeyPrefix.tokens" }

    /**
     * Unified token cache storing both "which tokens have been posted" (the key set) and
     * per-token metadata (the values) as a JSON object.
     *
     * Format: `{ "hashedToken1": { "isAutoRenewing": true }, "hashedToken2": { "isAutoRenewing": null } }`
     * - Keys = hashed tokens that have been successfully posted (replaces the old StringSet)
     * - Values = JSON objects with cached metadata. Currently stores `isAutoRenewing` status
     *   (`null` = unknown, e.g. migrated from legacy cache or posted via a path without the
     *   StoreTransaction). The map format allows adding more fields in the future without
     *   another migration.
     *
     * The `isAutoRenewing` values are used to detect subscription changes made outside the app
     * (e.g., cancellations in Play Store management). When `queryPurchases` returns a different
     * `isAutoRenewing` value than what's cached, the token is reposted so the backend can
     * re-check the subscription status with Google — avoiding a full `syncPurchases` which
     * reposts everything with `RESTORE` initiation source.
     */
    internal val tokensCacheKey: String by lazy { "$apiKeyPrefix.tokensV2" }

    /**
     * In-memory cache for the token map to avoid repeated JSON deserialization.
     * Populated on first read, invalidated on writes via [saveTokenMap].
     */
    private var tokenMapCache: Map<String, TokenCacheEntry>? = null

    @VisibleForTesting
    internal val storefrontCacheKey: String by lazy { "storefrontCacheKey" }

    private val productEntitlementMappingCacheKey: String by lazy {
        "$apiKeyPrefix.productEntitlementMapping"
    }
    private val productEntitlementMappingLastUpdatedCacheKey: String by lazy {
        "$apiKeyPrefix.productEntitlementMappingLastUpdated"
    }

    private val customerInfoCachesLastUpdatedCacheBaseKey: String by lazy {
        "$apiKeyPrefix.purchaserInfoLastUpdated"
    }

    private val virtualCurrenciesCacheBaseKey: String by lazy {
        "$apiKeyPrefix.virtualCurrencies"
    }

    private val virtualCurrenciesLastUpdatedCacheBaseKey: String by lazy {
        "$apiKeyPrefix.virtualCurrenciesLastUpdated"
    }

    private val offeringsResponseCacheKey: String by lazy { "$apiKeyPrefix.offeringsResponse" }

    internal fun startEditing(): SharedPreferences.Editor {
        return preferences.edit()
    }

    // region app user id

    @Synchronized
    internal fun getLegacyCachedAppUserID(): String? = preferences.getString(legacyAppUserIDCacheKey, null)

    @Synchronized
    internal fun getCachedAppUserID(): String? = preferences.getString(appUserIDCacheKey, null)

    @Synchronized
    internal fun cacheAppUserID(appUserID: String) {
        cacheAppUserID(appUserID, preferences.edit()).apply()
    }

    @Synchronized
    internal fun cacheAppUserID(
        appUserID: String,
        cacheEditor: SharedPreferences.Editor,
    ): SharedPreferences.Editor {
        return cacheEditor.putString(appUserIDCacheKey, appUserID)
    }

    @Synchronized
    internal fun clearCachesForAppUserID(appUserID: String) {
        preferences.edit()
            .clearCustomerInfo()
            .clearAppUserID()
            .clearCustomerInfoCacheTimestamp(appUserID)
            .clearVirtualCurrenciesCacheTimestamp(appUserID)
            .clearVirtualCurrenciesCache(appUserID)
            .apply()
    }

    private fun SharedPreferences.Editor.clearCustomerInfo(): SharedPreferences.Editor {
        getCachedAppUserID()?.let {
            remove(customerInfoCacheKey(it))
        }
        getLegacyCachedAppUserID()?.let {
            remove(customerInfoCacheKey(it))
        }
        return this
    }

    private fun SharedPreferences.Editor.clearAppUserID(): SharedPreferences.Editor {
        remove(appUserIDCacheKey)
        remove(legacyAppUserIDCacheKey)
        return this
    }

    private fun SharedPreferences.Editor.clearCustomerInfoCacheTimestamp(appUserID: String): SharedPreferences.Editor {
        remove(customerInfoLastUpdatedCacheKey(appUserID))
        return this
    }

    // endregion

    // region purchaser info
    @VisibleForTesting
    internal fun customerInfoCacheKey(appUserID: String) = "$legacyAppUserIDCacheKey.$appUserID"

    @VisibleForTesting
    internal fun customerInfoLastUpdatedCacheKey(appUserID: String) =
        "$customerInfoCachesLastUpdatedCacheBaseKey.$appUserID"

    @Suppress
    internal fun getCachedCustomerInfo(appUserID: String): CustomerInfo? {
        return preferences.getString(customerInfoCacheKey(appUserID), null)
            ?.let { json ->
                try {
                    val cachedJSONObject = JSONObject(json)
                    val schemaVersion = cachedJSONObject.optInt(CUSTOMER_INFO_SCHEMA_VERSION_KEY)
                    val verificationResultString = if (cachedJSONObject.has(CUSTOMER_INFO_VERIFICATION_RESULT_KEY)) {
                        cachedJSONObject.getString(CUSTOMER_INFO_VERIFICATION_RESULT_KEY)
                    } else {
                        VerificationResult.NOT_REQUESTED.name
                    }
                    val requestDate = cachedJSONObject.optLong(CUSTOMER_INFO_REQUEST_DATE_KEY).takeIf { it > 0 }?.let {
                        Date(it)
                    }
                    val originalSourceString = cachedJSONObject.optNullableString(CUSTOMER_INFO_ORIGINAL_SOURCE_KEY)
                    val originalSource = CustomerInfoOriginalSource.fromString(originalSourceString)
                    cachedJSONObject.remove(CUSTOMER_INFO_VERIFICATION_RESULT_KEY)
                    cachedJSONObject.remove(CUSTOMER_INFO_REQUEST_DATE_KEY)
                    cachedJSONObject.remove(CUSTOMER_INFO_ORIGINAL_SOURCE_KEY)
                    val verificationResult = VerificationResult.valueOf(verificationResultString)
                    return if (schemaVersion == CUSTOMER_INFO_SCHEMA_VERSION) {
                        CustomerInfoFactory.buildCustomerInfo(
                            cachedJSONObject,
                            requestDate,
                            verificationResult,
                            originalSource,
                            loadedFromCache = true,
                        )
                    } else {
                        null
                    }
                } catch (e: JSONException) {
                    null
                }
            }
    }

    @Synchronized
    internal fun cacheCustomerInfo(appUserID: String, info: CustomerInfo) {
        val jsonObject = info.rawData.also {
            it.put(CUSTOMER_INFO_SCHEMA_VERSION_KEY, CUSTOMER_INFO_SCHEMA_VERSION)
            it.put(CUSTOMER_INFO_VERIFICATION_RESULT_KEY, info.entitlements.verification.name)
            it.put(CUSTOMER_INFO_REQUEST_DATE_KEY, info.requestDate.time)
            it.put(CUSTOMER_INFO_ORIGINAL_SOURCE_KEY, info.originalSource.name)
        }
        preferences.edit()
            .putString(
                customerInfoCacheKey(appUserID),
                jsonObject.toString(),
            ).apply()

        setCustomerInfoCacheTimestampToNow(appUserID)
    }

    @Synchronized
    internal fun isCustomerInfoCacheStale(appUserID: String, appInBackground: Boolean) =
        getCustomerInfoCachesLastUpdated(appUserID).isCacheStale(appInBackground, dateProvider)

    @Synchronized
    internal fun clearCustomerInfoCacheTimestamp(appUserID: String) {
        preferences.edit().clearCustomerInfoCacheTimestamp(appUserID).apply()
    }

    @Synchronized
    internal fun clearCustomerInfoCache(appUserID: String) {
        val editor = preferences.edit()
        clearCustomerInfoCache(appUserID, editor)
        editor.apply()
    }

    @Synchronized
    internal fun clearCustomerInfoCache(
        appUserID: String,
        editor: SharedPreferences.Editor,
    ) {
        editor.clearCustomerInfoCacheTimestamp(appUserID)
        editor.remove(customerInfoCacheKey(appUserID))
    }

    @Synchronized
    internal fun setCustomerInfoCacheTimestampToNow(appUserID: String) {
        setCustomerInfoCacheTimestamp(appUserID, dateProvider.now)
    }

    @Synchronized
    @VisibleForTesting
    internal fun setCustomerInfoCacheTimestamp(appUserID: String, date: Date) {
        preferences.edit().putLong(customerInfoLastUpdatedCacheKey(appUserID), date.time).apply()
    }

    @Synchronized
    internal fun setStorefront(countryCode: String) {
        verboseLog { BillingStrings.BILLING_STOREFRONT_CACHING.format(countryCode) }
        preferences.edit().putString(storefrontCacheKey, countryCode).apply()
    }

    @Synchronized
    override fun getStorefront(): String? {
        val storefront = preferences.getString(storefrontCacheKey, null)
        if (storefront == null) {
            debugLog { BillingStrings.BILLING_STOREFRONT_NULL_FROM_CACHE }
        }
        return storefront
    }

    @Synchronized
    private fun getCustomerInfoCachesLastUpdated(appUserID: String): Date {
        return Date(preferences.getLong(customerInfoLastUpdatedCacheKey(appUserID), 0))
    }

    // endregion

    // region virtual currencies
    @VisibleForTesting
    internal fun virtualCurrenciesCacheKey(appUserID: String) = "$virtualCurrenciesCacheBaseKey.$appUserID"

    @VisibleForTesting
    internal fun virtualCurrenciesLastUpdatedCacheKey(appUserID: String) =
        "$virtualCurrenciesLastUpdatedCacheBaseKey.$appUserID"

    @Suppress("SwallowedException", "ForbiddenComment")
    @Synchronized
    internal fun getCachedVirtualCurrencies(appUserID: String): VirtualCurrencies? {
        return preferences.getString(virtualCurrenciesCacheKey(appUserID), null)
            ?.let { json ->
                try {
                    return VirtualCurrenciesFactory.buildVirtualCurrencies(jsonString = json)
                } catch (error: JSONException) {
                    log(LogIntent.WARNING) {
                        VirtualCurrencyStrings.ERROR_DECODING_CACHED_VIRTUAL_CURRENCIES.format(error)
                    }
                    null
                } catch (error: SerializationException) {
                    log(LogIntent.WARNING) {
                        VirtualCurrencyStrings.ERROR_DECODING_CACHED_VIRTUAL_CURRENCIES.format(error)
                    }
                    null
                } catch (error: IllegalArgumentException) {
                    log(LogIntent.WARNING) {
                        VirtualCurrencyStrings.ERROR_DECODING_CACHED_VIRTUAL_CURRENCIES.format(error)
                    }
                    null
                }
            }
    }

    @Synchronized
    internal fun cacheVirtualCurrencies(appUserID: String, virtualCurrencies: VirtualCurrencies) {
        val virtualCurrenciesJSONString = Json.Default.encodeToString(VirtualCurrencies.serializer(), virtualCurrencies)

        preferences.edit()
            .putString(
                virtualCurrenciesCacheKey(appUserID),
                virtualCurrenciesJSONString,
            ).apply()

        setVirtualCurrenciesCacheTimestampToNow(appUserID)
    }

    @Synchronized
    internal fun isVirtualCurrenciesCacheStale(appUserID: String, appInBackground: Boolean) =
        getVirtualCurrenciesCacheLastUpdated(appUserID)
            .isCacheStale(appInBackground, dateProvider)

    @Synchronized
    internal fun clearVirtualCurrenciesCache(appUserID: String) {
        val editor = preferences.edit()
        clearVirtualCurrenciesCache(appUserID, editor)
        editor.apply()
    }

    @Synchronized
    internal fun clearVirtualCurrenciesCache(
        appUserID: String,
        editor: SharedPreferences.Editor,
    ) {
        editor.clearVirtualCurrenciesCacheTimestamp(appUserID = appUserID)
        editor.clearVirtualCurrenciesCache(appUserID = appUserID)
    }

    @Synchronized
    private fun setVirtualCurrenciesCacheTimestampToNow(appUserID: String) {
        setVirtualCurrenciesCacheTimestamp(appUserID, dateProvider.now)
    }

    @Synchronized
    private fun setVirtualCurrenciesCacheTimestamp(appUserID: String, date: Date) {
        preferences.edit().putLong(virtualCurrenciesLastUpdatedCacheKey(appUserID), date.time).apply()
    }

    @Synchronized
    private fun getVirtualCurrenciesCacheLastUpdated(appUserID: String): Date {
        return Date(preferences.getLong(virtualCurrenciesLastUpdatedCacheKey(appUserID), 0))
    }

    private fun SharedPreferences.Editor.clearVirtualCurrenciesCacheTimestamp(
        appUserID: String,
    ): SharedPreferences.Editor {
        remove(virtualCurrenciesLastUpdatedCacheKey(appUserID))

        getCachedAppUserID()?.let {
            remove(virtualCurrenciesLastUpdatedCacheKey(it))
        }
        getLegacyCachedAppUserID()?.let {
            remove(virtualCurrenciesLastUpdatedCacheKey(it))
        }
        return this
    }

    private fun SharedPreferences.Editor.clearVirtualCurrenciesCache(appUserID: String): SharedPreferences.Editor {
        remove(virtualCurrenciesCacheKey(appUserID))

        getCachedAppUserID()?.let {
            remove(virtualCurrenciesCacheKey(it))
        }
        getLegacyCachedAppUserID()?.let {
            remove(virtualCurrenciesCacheKey(it))
        }
        return this
    }
    // endregion

    // region attribution data

    @Synchronized
    internal fun cleanupOldAttributionData() {
        val editor = preferences.edit()
        for (key in preferences.all.keys) {
            if (key != null && key.startsWith(attributionCacheKey)) {
                editor.remove(key)
            }
        }
        editor.apply()
    }

    // endregion

    // region purchase tokens

    /**
     * Returns the unified token map (hashedToken → metadata), migrating from legacy
     * StringSet format if needed. The key set represents all previously sent tokens; the values
     * contain per-token metadata (currently just isAutoRenewing, null = unknown).
     */
    @Synchronized
    private fun getTokenMap(): Map<String, TokenCacheEntry> {
        tokenMapCache?.let { return it }

        val result = loadTokenMapFromPreferences()
        tokenMapCache = result
        return result
    }

    private fun loadTokenMapFromPreferences(): Map<String, TokenCacheEntry> {
        val json = preferences.getString(tokensCacheKey, null)
        if (json != null) {
            return try {
                Json.decodeFromString(tokenMapSerializer, json)
            } catch (@Suppress("SwallowedException") e: SerializationException) {
                emptyMap()
            } catch (@Suppress("SwallowedException") e: IllegalArgumentException) {
                emptyMap()
            }
        }
        // Migrate from legacy StringSet if it exists
        return try {
            val legacyTokens = preferences.getStringSet(legacyTokensCacheKey, null)?.toSet()
            if (legacyTokens != null) {
                val migrated = legacyTokens.associateWith { TokenCacheEntry() }
                saveTokenMap(migrated)
                preferences.edit().remove(legacyTokensCacheKey).apply()
                log(LogIntent.DEBUG) { ReceiptStrings.TOKENS_ALREADY_POSTED.format(migrated.keys) }
                migrated
            } else {
                emptyMap()
            }
        } catch (@Suppress("SwallowedException") e: ClassCastException) {
            emptyMap()
        }
    }

    @Synchronized
    private fun saveTokenMap(tokenMap: Map<String, TokenCacheEntry>) {
        log(LogIntent.DEBUG) { ReceiptStrings.SAVING_TOKENS.format(tokenMap.keys) }
        putString(tokensCacheKey, Json.encodeToString(tokenMapSerializer, tokenMap))
        tokenMapCache = tokenMap
    }

    @Synchronized
    internal fun getPreviouslySentHashedTokens(): Set<String> {
        return getTokenMap().keys.also {
            log(LogIntent.DEBUG) { ReceiptStrings.TOKENS_ALREADY_POSTED.format(it) }
        }
    }

    @InternalRevenueCatAPI
    @Synchronized
    public fun addSuccessfullyPostedToken(token: String, isAutoRenewing: Boolean? = null) {
        val hashedToken = token.sha1()
        log(LogIntent.DEBUG) { ReceiptStrings.SAVING_TOKENS_WITH_HASH.format(token, hashedToken) }
        val current = getTokenMap().toMutableMap()
        log(LogIntent.DEBUG) { ReceiptStrings.TOKENS_IN_CACHE.format(current.keys) }
        val existing = current[hashedToken]
        if (existing == null) {
            current[hashedToken] = TokenCacheEntry(isAutoRenewing = isAutoRenewing)
            saveTokenMap(current)
        } else if (isAutoRenewing != null && existing.isAutoRenewing != isAutoRenewing) {
            current[hashedToken] = existing.copy(isAutoRenewing = isAutoRenewing)
            saveTokenMap(current)
        }
    }

    /**
     * Removes from the database all hashed tokens that are not considered active anymore, i.e. all
     * consumed in-apps or inactive subscriptions hashed tokens that are still in the local cache.
     */
    @Synchronized
    internal fun cleanPreviouslySentTokens(
        hashedTokens: Set<String>,
    ) {
        log(LogIntent.DEBUG) { ReceiptStrings.CLEANING_PREV_SENT_HASHED_TOKEN }
        val current = getTokenMap()
        val cleaned = current.filterKeys { it in hashedTokens }
        saveTokenMap(cleaned)
    }

    /**
     * Returns a list containing all tokens that are in [hashedTokens]
     * that are not present in the device cache.
     * In other words, returns all hashed tokens that are active and have not
     * been posted to our backend yet.
     */
    @Synchronized
    internal fun getActivePurchasesNotInCache(
        hashedTokens: Map<String, StoreTransaction>,
    ): List<StoreTransaction> {
        return hashedTokens
            .minus(getPreviouslySentHashedTokens())
            .values.toList()
    }

    /**
     * Returns purchases whose [StoreTransaction.isAutoRenewing] status has changed compared to
     * the cached value. This detects subscription changes made outside the app (e.g., cancellations
     * in Play Store subscription management) without requiring a full syncPurchases.
     */
    @Synchronized
    internal fun getPurchasesWithAutoRenewingChange(
        hashedTokens: Map<String, StoreTransaction>,
    ): List<StoreTransaction> {
        val tokenMap = getTokenMap()
        return hashedTokens.filter { (hash, transaction) ->
            val cachedEntry = tokenMap[hash]
            cachedEntry != null &&
                cachedEntry.isAutoRenewing != null &&
                transaction.isAutoRenewing != null &&
                transaction.isAutoRenewing != cachedEntry.isAutoRenewing
        }.values.toList()
    }

    /**
     * Saves the auto-renewing status for all given hashed tokens. Tokens already in the cache
     * get their status updated; tokens not in the cache are ignored (they haven't been posted yet).
     */
    @Synchronized
    internal fun saveAutoRenewingStatus(hashedTokens: Map<String, StoreTransaction>) {
        val current = getTokenMap().toMutableMap()
        var changed = false
        for ((hash, transaction) in hashedTokens) {
            val existing = current[hash]
            if (existing != null && transaction.isAutoRenewing != null &&
                existing.isAutoRenewing != transaction.isAutoRenewing
            ) {
                current[hash] = existing.copy(isAutoRenewing = transaction.isAutoRenewing)
                changed = true
            }
        }
        if (changed) {
            saveTokenMap(current)
        }
    }

    // endregion

    // region offerings response

    @Synchronized
    internal fun getOfferingsResponseCache(): JSONObject? {
        return getJSONObjectOrNull(offeringsResponseCacheKey)
    }

    @Synchronized
    internal fun cacheOfferingsResponse(offeringsResponse: JSONObject) {
        preferences.edit()
            .putString(
                offeringsResponseCacheKey,
                offeringsResponse.toString(),
            ).apply()
    }

    @Synchronized
    internal fun clearOfferingsResponseCache() {
        preferences.edit().remove(offeringsResponseCacheKey).apply()
    }

    // endregion

    // region ProductEntitlementMapping

    @Synchronized
    internal fun cacheProductEntitlementMapping(productEntitlementMapping: ProductEntitlementMapping) {
        val json = productEntitlementMapping.toJson()
        preferences.edit()
            .putString(
                productEntitlementMappingCacheKey,
                json.toString(),
            )
            .apply()

        setProductEntitlementMappingCacheTimestampToNow()
    }

    @Synchronized
    @VisibleForTesting
    internal fun setProductEntitlementMappingCacheTimestampToNow() {
        setProductEntitlementMappingCacheTimestamp(dateProvider.now)
    }

    private fun setProductEntitlementMappingCacheTimestamp(date: Date) {
        preferences.edit().putLong(productEntitlementMappingLastUpdatedCacheKey, date.time).apply()
    }

    @Synchronized
    internal fun isProductEntitlementMappingCacheStale(): Boolean {
        return getProductEntitlementMappingLastUpdated().isCacheStale(
            PRODUCT_ENTITLEMENT_MAPPING_CACHE_REFRESH_PERIOD,
            dateProvider,
        )
    }

    @Suppress("NestedBlockDepth")
    @Synchronized
    internal fun getProductEntitlementMapping(): ProductEntitlementMapping? {
        return preferences.getString(productEntitlementMappingCacheKey, null)?.let { jsonString ->
            return try {
                val jsonObject = JSONObject(jsonString)
                ProductEntitlementMapping.fromJson(jsonObject, loadedFromCache = true)
            } catch (e: JSONException) {
                errorLog(e) { OfflineEntitlementsStrings.ERROR_PARSING_PRODUCT_ENTITLEMENT_MAPPING.format(jsonString) }
                preferences.edit()
                    .remove(productEntitlementMappingCacheKey)
                    .apply()
                null
            }
        }
    }

    private fun getProductEntitlementMappingLastUpdated(): Date? {
        return if (preferences.contains(productEntitlementMappingLastUpdatedCacheKey)) {
            Date(preferences.getLong(productEntitlementMappingLastUpdatedCacheKey, -1))
        } else {
            null
        }
    }

    // endregion

    // region utils

    internal open fun getJSONObjectOrNull(key: String): JSONObject? {
        return preferences.getString(key, null)?.let { json ->
            try {
                JSONObject(json)
            } catch (e: JSONException) {
                null
            }
        }
    }

    internal open fun putString(
        cacheKey: String,
        value: String,
    ) {
        preferences.edit().putString(
            cacheKey,
            value,
        ).apply()
    }

    internal fun remove(
        cacheKey: String,
    ) {
        preferences.edit().remove(cacheKey).apply()
    }

    internal fun findKeysThatStartWith(
        cacheKey: String,
    ): Set<String> {
        return try {
            preferences.all
                ?.filterKeys { it.startsWith(cacheKey) }
                ?.keys ?: emptySet()
        } catch (e: NullPointerException) {
            emptySet()
        }
    }

    internal fun newKey(
        key: String,
    ) = "$apiKeyPrefix.$key"

    // endregion
}
