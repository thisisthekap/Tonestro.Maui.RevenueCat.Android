//  Purchases
//
//  Copyright © 2019 RevenueCat, Inc. All rights reserved.
//

package com.revenuecat.purchases.google

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import androidx.annotation.UiThread
import androidx.annotation.VisibleForTesting
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingFlowParams.ProductDetailsParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.InAppMessageParams
import com.android.billingclient.api.InAppMessageResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.revenuecat.purchases.ExperimentalPreviewRevenueCatPurchasesAPI
import com.revenuecat.purchases.InternalRevenueCatAPI
import com.revenuecat.purchases.NoCoreLibraryDesugaringException
import com.revenuecat.purchases.PostReceiptInitiationSource
import com.revenuecat.purchases.PresentedOfferingContext
import com.revenuecat.purchases.ProductType
import com.revenuecat.purchases.PurchasesError
import com.revenuecat.purchases.PurchasesErrorCallback
import com.revenuecat.purchases.PurchasesErrorCode
import com.revenuecat.purchases.PurchasesStateProvider
import com.revenuecat.purchases.common.BillingAbstract
import com.revenuecat.purchases.common.DateProvider
import com.revenuecat.purchases.common.DefaultDateProvider
import com.revenuecat.purchases.common.LogIntent
import com.revenuecat.purchases.common.ReplaceProductInfo
import com.revenuecat.purchases.common.StoreProductsCallback
import com.revenuecat.purchases.common.caching.DeviceCache
import com.revenuecat.purchases.common.debugLog
import com.revenuecat.purchases.common.diagnostics.DiagnosticsTracker
import com.revenuecat.purchases.common.errorLog
import com.revenuecat.purchases.common.firstProductId
import com.revenuecat.purchases.common.log
import com.revenuecat.purchases.common.sha256
import com.revenuecat.purchases.common.toHumanReadableDescription
import com.revenuecat.purchases.common.verboseLog
import com.revenuecat.purchases.google.usecase.AcknowledgePurchaseUseCase
import com.revenuecat.purchases.google.usecase.AcknowledgePurchaseUseCaseParams
import com.revenuecat.purchases.google.usecase.ConsumePurchaseUseCase
import com.revenuecat.purchases.google.usecase.ConsumePurchaseUseCaseParams
import com.revenuecat.purchases.google.usecase.GetBillingConfigUseCase
import com.revenuecat.purchases.google.usecase.GetBillingConfigUseCaseParams
import com.revenuecat.purchases.google.usecase.QueryProductDetailsUseCase
import com.revenuecat.purchases.google.usecase.QueryProductDetailsUseCaseParams
import com.revenuecat.purchases.google.usecase.QueryPurchaseHistoryUseCase
import com.revenuecat.purchases.google.usecase.QueryPurchaseHistoryUseCaseParams
import com.revenuecat.purchases.google.usecase.QueryPurchasesByTypeUseCase
import com.revenuecat.purchases.google.usecase.QueryPurchasesByTypeUseCaseParams
import com.revenuecat.purchases.google.usecase.QueryPurchasesUseCase
import com.revenuecat.purchases.google.usecase.QueryPurchasesUseCaseParams
import com.revenuecat.purchases.models.GooglePurchasingData
import com.revenuecat.purchases.models.GooglePurchasingData.Subscription
import com.revenuecat.purchases.models.GoogleReplacementMode
import com.revenuecat.purchases.models.InAppMessageType
import com.revenuecat.purchases.models.PurchaseState
import com.revenuecat.purchases.models.PurchasingData
import com.revenuecat.purchases.models.StoreReplacementMode
import com.revenuecat.purchases.models.StoreTransaction
import com.revenuecat.purchases.models.toStoreReplacementModeOrNull
import com.revenuecat.purchases.strings.BillingStrings
import com.revenuecat.purchases.strings.OfferingStrings
import com.revenuecat.purchases.strings.PurchaseStrings
import com.revenuecat.purchases.strings.RestoreStrings
import com.revenuecat.purchases.utils.Result
import java.io.PrintWriter
import java.io.StringWriter
import java.lang.ref.WeakReference
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.min

private const val RECONNECT_TIMER_START_MILLISECONDS = 1L * 1000L
private const val RECONNECT_TIMER_MAX_TIME_MILLISECONDS = 1000L * 60L * 15L // 15 minutes

@OptIn(InternalRevenueCatAPI::class)
@Suppress("LargeClass", "TooManyFunctions", "LongParameterList")
internal class BillingWrapper(
    private val clientFactory: ClientFactory,
    private val mainHandler: Handler,
    backgroundHandler: Handler? = null,
    private val deviceCache: DeviceCache,
    @Suppress("unused")
    private val diagnosticsTrackerIfEnabled: DiagnosticsTracker?,
    purchasesStateProvider: PurchasesStateProvider,
    private val applyObfuscatedAccountIdToSubscriptionChanges: Boolean = false,
    private val dateProvider: DateProvider = DefaultDateProvider(),
) : BillingAbstract(purchasesStateProvider), PurchasesUpdatedListener, BillingClientStateListener {

    // Only non-null when BillingWrapper created the thread itself — used to quit on close.
    @VisibleForTesting(otherwise = VisibleForTesting.PRIVATE)
    internal val ownedBackgroundThread: HandlerThread? = if (backgroundHandler == null) {
        HandlerThread("revenuecat-billing").apply { start() }
    } else {
        null
    }

    private val backgroundHandler: Handler =
        backgroundHandler ?: Handler(ownedBackgroundThread!!.looper)

    private companion object {
        /**
         * The maximum number of pending requests we report to diagnostics.
         */
        private const val MAX_PENDING_REQUEST_COUNT_REPORTED = 100
    }

    @get:Synchronized
    @set:Synchronized
    @Volatile
    var billingClient: BillingClient? = null

    @VisibleForTesting(otherwise = VisibleForTesting.PRIVATE)
    internal val purchaseContext = mutableMapOf<String, PurchaseContext>()

    private val serviceRequests =
        ConcurrentLinkedQueue<Pair<(connectionError: PurchasesError?) -> Unit, Long?>>()

    // how long before the data source tries to reconnect to Google play
    private var reconnectMilliseconds = RECONNECT_TIMER_START_MILLISECONDS

    @get:Synchronized
    @set:Synchronized
    private var reconnectionAlreadyScheduled = false

    val appInBackground: Boolean
        get() = purchasesStateProvider.purchasesState.appInBackground

    class ClientFactory(
        private val context: Context,
        private val pendingTransactionsForPrepaidPlansEnabled: Boolean,
    ) {
        fun buildClient(listener: com.android.billingclient.api.PurchasesUpdatedListener): BillingClient {
            val pendingPurchaseParams = PendingPurchasesParams.newBuilder()
                .enableOneTimeProducts()
                .apply { if (pendingTransactionsForPrepaidPlansEnabled) enablePrepaidPlans() }
                .build()
            return BillingClient.newBuilder(context).enablePendingPurchases(pendingPurchaseParams).setListener(listener)
                .build()
        }
    }

    private fun executePendingRequests() {
        synchronized(this@BillingWrapper) {
            while (billingClient?.isReady == true) {
                serviceRequests.poll()?.let { (request, delayMilliseconds) ->
                    if (delayMilliseconds != null) {
                        mainHandler.postDelayed(
                            { request(null) },
                            delayMilliseconds,
                        )
                    } else {
                        mainHandler.post { request(null) }
                    }
                } ?: break
            }
        }
    }

    override fun startConnection(delayMilliseconds: Long) {
        backgroundHandler.postDelayed(
            { performStartConnection() },
            delayMilliseconds,
        )
    }

    private fun performStartConnection() {
        try {
            // Keep the monitor scope limited to state mutation so the slow `startConnection(...)`
            // call below doesn't hold off main-thread callers that synchronize on this wrapper.
            val clientToStart = synchronized(this@BillingWrapper) {
                if (billingClient == null) {
                    billingClient = clientFactory.buildClient(this)
                }
                reconnectionAlreadyScheduled = false
                billingClient?.takeIf { !it.isReady }
            } ?: return

            log(LogIntent.DEBUG) { BillingStrings.BILLING_CLIENT_STARTING.format(clientToStart) }
            diagnosticsTrackerIfEnabled?.trackGoogleBillingStartConnection()
            clientToStart.startConnection(this)
        } catch (e: IllegalStateException) {
            log(LogIntent.GOOGLE_ERROR) {
                BillingStrings.ILLEGAL_STATE_EXCEPTION_WHEN_CONNECTING.format(e)
            }
            val error = PurchasesError(PurchasesErrorCode.StoreProblemError, e.message)
            sendErrorsToAllPendingRequests(error)
        } catch (e: SecurityException) {
            errorLog(e) { BillingStrings.SECURITY_EXCEPTION_WHEN_CONNECTING }
            val error = PurchasesError(PurchasesErrorCode.StoreProblemError, e.message)
            sendErrorsToAllPendingRequests(error)
        } catch (@Suppress("TooGenericExceptionCaught") e: Throwable) {
            // Preserve pre-background-thread behavior: any other throwable would have surfaced
            // as an uncaught exception on the main thread and crashed the app. Rethrow on the
            // main thread so the failure is visible in the same way.
            errorLog(e) { "Unexpected error while starting the billing connection" }
            mainHandler.post { throw e }
        }
    }

    override fun endConnection() {
        backgroundHandler.post {
            synchronized(this@BillingWrapper) {
                billingClient?.let {
                    log(LogIntent.DEBUG) { BillingStrings.BILLING_CLIENT_ENDING.format(it) }
                    it.endConnection()
                }
                billingClient = null
            }
        }
    }

    override fun close() {
        super.close()
        // quitSafely lets the cleanup runnable enqueued by endConnection() drain before the
        // looper exits, so the HandlerThread is released without dropping pending work.
        ownedBackgroundThread?.quitSafely()
    }

    @Synchronized
    private fun executeRequestOnUIThread(delayMilliseconds: Long? = null, request: (PurchasesError?) -> Unit) {
        if (purchasesUpdatedListener != null) {
            serviceRequests.add(request to delayMilliseconds)
            if (billingClient?.isReady == false) {
                startConnection()
            } else {
                executePendingRequests()
            }
        } else {
            // This shouldn't happen, but if it does, we want to propagate an error instead of hanging.
            request(PurchasesError(PurchasesErrorCode.UnknownError, "BillingWrapper is not attached to a listener"))
        }
    }

    @Suppress("LongMethod")
    override fun queryProductDetailsAsync(
        productType: ProductType,
        productIds: Set<String>,
        onReceive: StoreProductsCallback,
        onError: PurchasesErrorCallback,
    ) {
        log(LogIntent.DEBUG) { OfferingStrings.FETCHING_PRODUCTS.format(productIds.joinToString()) }
        val useCase = QueryProductDetailsUseCase(
            QueryProductDetailsUseCaseParams(
                dateProvider,
                diagnosticsTrackerIfEnabled,
                productIds,
                productType,
                appInBackground,
            ),
            onReceive,
            onError,
            ::withConnectedClient,
            ::executeRequestOnUIThread,
        )
        useCase.run()
    }

    @OptIn(ExperimentalPreviewRevenueCatPurchasesAPI::class)
    @Suppress("LongMethod")
    override fun makePurchaseAsync(
        activity: Activity,
        appUserID: String,
        purchasingData: PurchasingData,
        replaceProductInfo: ReplaceProductInfo?,
        presentedOfferingContext: PresentedOfferingContext?,
        isPersonalizedPrice: Boolean?,
    ) {
        val googlePurchasingData = purchasingData as? GooglePurchasingData
        if (googlePurchasingData == null) {
            val error = PurchasesError(
                PurchasesErrorCode.UnknownError,
                PurchaseStrings.INVALID_PURCHASE_TYPE.format(
                    "Play",
                    "GooglePurchasingData",
                ),
            )
            errorLog(error)
            purchasesUpdatedListener?.onPurchasesFailedToUpdate(error)
            return
        }

        val subscriptionOptionId = when (googlePurchasingData) {
            is GooglePurchasingData.InAppProduct -> {
                null
            }

            is GooglePurchasingData.Subscription -> {
                googlePurchasingData.optionId
            }
        }

        if (replaceProductInfo != null) {
            log(LogIntent.PURCHASE) {
                PurchaseStrings.UPGRADING_SKU
                    .format(replaceProductInfo.oldPurchase.productIds[0], googlePurchasingData.productId)
            }
        } else {
            log(LogIntent.PURCHASE) { PurchaseStrings.PURCHASING_PRODUCT.format(googlePurchasingData.productId) }
        }

        synchronized(this@BillingWrapper) {
            // When using DEFERRED proration mode, callback needs to be associated with the *old* product we are
            // switching from, because the transaction we receive on successful purchase is for the old product.
            val productId =
                if (replaceProductInfo?.replacementMode == StoreReplacementMode.DEFERRED ||
                    replaceProductInfo?.replacementMode == GoogleReplacementMode.DEFERRED
                ) {
                    replaceProductInfo.oldPurchase.productIds.first()
                } else {
                    googlePurchasingData.productId
                }

            // Create a map that tells us which subscription option ID was purchased for a given product ID.
            // This is required for multi-line subscriptions to set the platform_product_ids in the ReceiptInfo
            // after the purchase has completed.
            val subscriptionOptionIdForProductIDs = buildMap {
                subscriptionOptionId?.let { optionId -> put(googlePurchasingData.productId, optionId) }

                (googlePurchasingData as? GooglePurchasingData.Subscription)
                    ?.addOnProducts
                    ?.filterIsInstance<GooglePurchasingData.Subscription>()
                    ?.forEach { addOnProduct ->
                        put(addOnProduct.productId, addOnProduct.optionId)
                    }
            }

            purchaseContext[productId] = PurchaseContext(
                googlePurchasingData.productType,
                presentedOfferingContext,
                subscriptionOptionId,
                replaceProductInfo?.replacementMode.toStoreReplacementModeOrNull(),
                subscriptionOptionIdForProductIDs,
            )
        }
        executeRequestOnUIThread {
            val result = buildPurchaseParams(
                purchasingData,
                replaceProductInfo,
                appUserID,
                isPersonalizedPrice,
            )
            when (result) {
                is Result.Success -> {
                    trackPurchaseStartIfNeeded(
                        googlePurchasingData,
                        replaceProductInfo?.oldPurchase?.productIds?.firstOrNull(),
                    )
                    launchBillingFlow(activity, result.value)
                }
                is Result.Error -> purchasesUpdatedListener?.onPurchasesFailedToUpdate(result.value)
            }
        }
    }

    @UiThread
    private fun launchBillingFlow(
        activity: Activity,
        params: BillingFlowParams,
    ) {
        if (activity.intent == null) {
            log(LogIntent.WARNING) { BillingStrings.NULL_ACTIVITY_INTENT }
        }
        withConnectedClient {
            launchBillingFlow(activity, params)
                .takeIf { billingResult -> billingResult.responseCode != BillingClient.BillingResponseCode.OK }
                ?.let { billingResult ->
                    log(LogIntent.GOOGLE_ERROR) {
                        BillingStrings.BILLING_INTENT_FAILED
                            .format(billingResult.toHumanReadableDescription())
                    }
                }
        }
    }

    fun queryPurchaseHistoryAsync(
        @BillingClient.ProductType productType: String,
        onReceivePurchaseHistory: (List<StoreTransaction>) -> Unit,
        onReceivePurchaseHistoryError: (PurchasesError) -> Unit,
    ) {
        log(LogIntent.DEBUG) { RestoreStrings.QUERYING_PURCHASE_HISTORY.format(productType) }
        QueryPurchaseHistoryUseCase(
            QueryPurchaseHistoryUseCaseParams(
                dateProvider,
                diagnosticsTrackerIfEnabled,
                productType,
                appInBackground,
            ),
            onReceivePurchaseHistory,
            onReceivePurchaseHistoryError,
            ::withConnectedClient,
            ::executeRequestOnUIThread,
        ).run()
    }

    override fun queryAllPurchases(
        appUserID: String,
        onReceivePurchaseHistory: (List<StoreTransaction>) -> Unit,
        onReceivePurchaseHistoryError: (PurchasesError) -> Unit,
    ) {
        queryPurchaseHistoryAsync(
            BillingClient.ProductType.SUBS,
            { subsPurchasesList ->
                queryPurchaseHistoryAsync(
                    BillingClient.ProductType.INAPP,
                    { inAppPurchasesList ->
                        onReceivePurchaseHistory(
                            subsPurchasesList + inAppPurchasesList,
                        )
                    },
                    onReceivePurchaseHistoryError,
                )
            },
            onReceivePurchaseHistoryError,
        )
    }

    override fun consumeAndSave(
        finishTransactions: Boolean,
        purchase: StoreTransaction,
        shouldConsume: Boolean,
        initiationSource: PostReceiptInitiationSource,
    ) {
        if (purchase.type == ProductType.UNKNOWN || purchase.purchaseState == PurchaseState.PENDING) {
            // Product type will be unknown if the purchase was triggered from outside of the app and there was
            // an issue getting the purchase type
            // Exit early if purchase type is unknown or purchase is pending
            return
        }

        val originalGooglePurchase = purchase.originalGooglePurchase
        val alreadyAcknowledged = originalGooglePurchase?.isAcknowledged ?: false
        val isInAppProduct = purchase.type == ProductType.INAPP

        val addToken = { token: String ->
            deviceCache.addSuccessfullyPostedToken(token, purchase.isAutoRenewing)
        }

        if (isInAppProduct) {
            if (finishTransactions && shouldConsume) {
                consumePurchase(
                    purchase.purchaseToken,
                    initiationSource,
                    onConsumed = addToken,
                )
            } else if (finishTransactions && !alreadyAcknowledged) {
                log(LogIntent.PURCHASE) { PurchaseStrings.NOT_CONSUMING_IN_APP_PURCHASE_ACCORDING_TO_BACKEND }
                acknowledge(
                    purchase.purchaseToken,
                    initiationSource,
                    onAcknowledged = addToken,
                )
            } else {
                addToken(purchase.purchaseToken)
            }
        } else {
            if (finishTransactions && !alreadyAcknowledged) {
                acknowledge(
                    purchase.purchaseToken,
                    initiationSource,
                    onAcknowledged = addToken,
                )
            } else {
                addToken(purchase.purchaseToken)
            }
        }
    }

    internal fun consumePurchase(
        token: String,
        initiationSource: PostReceiptInitiationSource,
        onConsumed: (purchaseToken: String) -> Unit,
    ) {
        log(LogIntent.PURCHASE) { PurchaseStrings.CONSUMING_PURCHASE.format(token) }
        ConsumePurchaseUseCase(
            ConsumePurchaseUseCaseParams(
                token,
                initiationSource,
                appInBackground,
            ),
            onReceive = onConsumed,
            onError = { _ ->
                // TODO-retry: if ITEM_NOT_OWNED queryPurchasesAsync
            },
            ::withConnectedClient,
            ::executeRequestOnUIThread,
        ).run()
    }

    internal fun acknowledge(
        token: String,
        initiationSource: PostReceiptInitiationSource,
        onAcknowledged: (purchaseToken: String) -> Unit,
    ) {
        log(LogIntent.PURCHASE) { PurchaseStrings.ACKNOWLEDGING_PURCHASE.format(token) }
        AcknowledgePurchaseUseCase(
            AcknowledgePurchaseUseCaseParams(
                token,
                initiationSource,
                appInBackground,
            ),
            onReceive = onAcknowledged,
            { _ ->
                // TODO-retry: if ITEM_NOT_OWNED queryPurchasesAsync
            },
            ::withConnectedClient,
            ::executeRequestOnUIThread,
        ).run()
    }

    @Suppress("ReturnCount", "LongMethod")
    override fun queryPurchases(
        appUserID: String,
        onSuccess: (Map<String, StoreTransaction>) -> Unit,
        onError: (PurchasesError) -> Unit,
    ) {
        log(LogIntent.DEBUG) { RestoreStrings.QUERYING_PURCHASE }
        QueryPurchasesUseCase(
            QueryPurchasesUseCaseParams(
                dateProvider,
                diagnosticsTrackerIfEnabled,
                appInBackground,
            ),
            onSuccess,
            onError,
            ::withConnectedClient,
            ::executeRequestOnUIThread,
        ).run()
    }

    override fun findPurchaseInPurchaseHistory(
        appUserID: String,
        productType: ProductType,
        productId: String,
        onCompletion: (StoreTransaction) -> Unit,
        onError: (PurchasesError) -> Unit,
    ) {
        log(LogIntent.DEBUG) { RestoreStrings.QUERYING_PURCHASE_WITH_TYPE.format(productId, productType.name) }
        productType.toGoogleProductType()?.let { googleProductType ->
            QueryPurchaseHistoryUseCase(
                QueryPurchaseHistoryUseCaseParams(
                    dateProvider,
                    diagnosticsTrackerIfEnabled,
                    googleProductType,
                    appInBackground,
                ),
                { purchasesList ->
                    val purchaseTransaction =
                        purchasesList.firstOrNull { it.productIds.contains(productId) }
                    if (purchaseTransaction != null) {
                        onCompletion(purchaseTransaction)
                    } else {
                        val message = PurchaseStrings.NO_EXISTING_PURCHASE.format(productId)
                        val error = PurchasesError(PurchasesErrorCode.PurchaseInvalidError, message)
                        onError(error)
                    }
                },
                onError,
                ::withConnectedClient,
                ::executeRequestOnUIThread,
            ).run()
        } ?: onError(
            PurchasesError(PurchasesErrorCode.PurchaseInvalidError, PurchaseStrings.NOT_RECOGNIZED_PRODUCT_TYPE),
        )
    }

    @VisibleForTesting(otherwise = VisibleForTesting.PRIVATE)
    internal fun getPurchaseType(purchaseToken: String, listener: (ProductType) -> Unit) {
        queryPurchaseType(BillingClient.ProductType.SUBS, purchaseToken, listener) { subFound ->
            if (subFound) {
                listener(ProductType.SUBS)
            } else {
                queryPurchaseType(BillingClient.ProductType.INAPP, purchaseToken, listener) { inAppFound ->
                    if (inAppFound) {
                        listener(ProductType.INAPP)
                    } else {
                        listener(ProductType.UNKNOWN)
                    }
                }
            }
        }
    }

    private fun queryPurchaseType(
        productType: String,
        purchaseToken: String,
        listener: (ProductType) -> Unit,
        resultHandler: (Boolean) -> Unit,
    ) {
        QueryPurchasesByTypeUseCase(
            QueryPurchasesByTypeUseCaseParams(
                dateProvider,
                diagnosticsTrackerIfEnabled,
                appInBackground = appInBackground,
                productType = productType,
            ),
            onSuccess = { purchases ->
                resultHandler(purchases.values.any { it.purchaseToken == purchaseToken })
            },
            onError = { error ->
                errorLog(error)
                listener(ProductType.UNKNOWN)
            },
            withConnectedClient = ::withConnectedClient,
            executeRequestOnUIThread = ::executeRequestOnUIThread,
        ).run()
    }

    override fun onPurchasesUpdated(
        billingResult: BillingResult,
        purchases: List<Purchase>?,
    ) {
        trackPurchaseUpdateReceivedIfNeeded(billingResult, purchases)
        val notNullPurchasesList = purchases ?: emptyList()
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && notNullPurchasesList.isNotEmpty()) {
            val storeTransactions = mutableListOf<StoreTransaction>()
            notNullPurchasesList.forEach { purchase ->
                getStoreTransaction(purchase) { storeTxn ->
                    storeTransactions.add(storeTxn)
                    if (storeTransactions.size == notNullPurchasesList.size) {
                        purchasesUpdatedListener?.onPurchasesUpdated(storeTransactions)
                    }
                }
            }
        } else {
            log(LogIntent.GOOGLE_ERROR) {
                BillingStrings.BILLING_WRAPPER_PURCHASES_ERROR
                    .format(billingResult.toHumanReadableDescription()) +
                    (
                        notNullPurchasesList.takeUnless { it.isEmpty() }?.let { purchase ->
                            " Purchases:" + purchase.joinToString(
                                ", ",
                                transform = { it.toHumanReadableDescription() },
                            )
                        } ?: " No purchases received"
                        )
            }

            var message = "Error updating purchases. ${billingResult.toHumanReadableDescription()}"
            var responseCode = billingResult.responseCode

            if (purchases == null && billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                // Result being ok but with a Null purchase used to happen when doing a product change
                // in DEFERRED proration mode in Billing Client <= 4. Should not happen in Billing Client 5+ since
                // we get the transaction for the previous product.
                message = "Error: onPurchasesUpdated received an OK BillingResult with a Null purchases list."
                responseCode = BillingClient.BillingResponseCode.ERROR
            }

            val purchasesError = responseCode.billingResponseToPurchasesError(message).also { errorLog(it) }

            purchasesUpdatedListener?.onPurchasesFailedToUpdate(purchasesError)
        }
    }

    @Suppress("LongMethod")
    override fun onBillingSetupFinished(billingResult: BillingResult) {
        diagnosticsTrackerIfEnabled?.trackGoogleBillingSetupFinished(
            responseCode = billingResult.responseCode,
            debugMessage = billingResult.debugMessage,
            // serviceRequests.size is O(n), so cap our count to MAX_PENDING_REQUEST_COUNT_REPORTED items.
            pendingRequestCount = serviceRequests.asSequence().take(MAX_PENDING_REQUEST_COUNT_REPORTED).count(),
        )
        mainHandler.post {
            when (billingResult.responseCode) {
                BillingClient.BillingResponseCode.OK -> {
                    log(LogIntent.DEBUG) {
                        BillingStrings.BILLING_SERVICE_SETUP_FINISHED
                            .format(billingClient?.toString())
                    }
                    stateListener?.onConnected()
                    executePendingRequests()
                    reconnectMilliseconds = RECONNECT_TIMER_START_MILLISECONDS
                    trackProductDetailsNotSupportedIfNeeded()
                }

                BillingClient.BillingResponseCode.FEATURE_NOT_SUPPORTED,
                BillingClient.BillingResponseCode.BILLING_UNAVAILABLE,
                -> {
                    val originalErrorMessage = billingResult.toHumanReadableDescription()

                    /**
                     * We check for cases when Google sends Google Play In-app Billing API version is less than 3
                     * as a debug message. Version 3 is from 2012, so the message is a bit useless.
                     * We have detected this message in several cases:
                     *
                     * - When there's no Google account configured in the device
                     * - When there's no Play Store (this happens in incorrectly configured emulators)
                     * - When language is changed in the device and Play Store caches get corrupted. Opening the
                     * Play Store or clearing its caches would fix this case.
                     * See https://github.com/RevenueCat/purchases-android/issues/1288
                     */
                    val error = if (billingResult.debugMessage == IN_APP_BILLING_LESS_THAN_3_ERROR_MESSAGE) {
                        val underlyingErrorMessage =
                            BillingStrings.BILLING_UNAVAILABLE_LESS_THAN_3.format(originalErrorMessage)
                        PurchasesError(PurchasesErrorCode.StoreProblemError, underlyingErrorMessage)
                            .also { errorLog(it) }
                    } else {
                        val underlyingErrorMessage = BillingStrings.BILLING_UNAVAILABLE.format(originalErrorMessage)
                        billingResult.responseCode
                            .billingResponseToPurchasesError(underlyingErrorMessage)
                            .also { errorLog(it) }
                    }

                    // The calls will fail with an error that will be surfaced. We want to surface these errors
                    // Can't call executePendingRequests because it will not do anything since it checks for isReady()
                    sendErrorsToAllPendingRequests(error)
                }

                BillingClient.BillingResponseCode.ERROR,
                BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE,
                BillingClient.BillingResponseCode.USER_CANCELED,
                BillingClient.BillingResponseCode.SERVICE_DISCONNECTED,
                BillingClient.BillingResponseCode.NETWORK_ERROR,
                -> {
                    log(LogIntent.GOOGLE_WARNING) {
                        BillingStrings.BILLING_CLIENT_ERROR
                            .format(billingResult.toHumanReadableDescription())
                    }
                    retryBillingServiceConnectionWithExponentialBackoff()
                }

                BillingClient.BillingResponseCode.ITEM_UNAVAILABLE,
                BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED,
                BillingClient.BillingResponseCode.ITEM_NOT_OWNED,
                -> {
                    log(LogIntent.GOOGLE_WARNING) {
                        BillingStrings.BILLING_CLIENT_ERROR
                            .format(billingResult.toHumanReadableDescription())
                    }
                }

                BillingClient.BillingResponseCode.DEVELOPER_ERROR -> {
                    // Billing service is already trying to connect. Don't do anything.
                }
            }
        }
    }

    override fun onBillingServiceDisconnected() {
        log(LogIntent.WARNING) {
            BillingStrings.BILLING_SERVICE_DISCONNECTED_INSTANCE.format(billingClient?.toString())
        }
        diagnosticsTrackerIfEnabled?.trackGoogleBillingServiceDisconnected()
    }

    /**
     * Retries the billing service connection with exponential backoff, maxing out at the time
     * specified by RECONNECT_TIMER_MAX_TIME_MILLISECONDS.
     *
     * This prevents ANRs, see https://github.com/android/play-billing-samples/issues/310
     */
    private fun retryBillingServiceConnectionWithExponentialBackoff() {
        if (reconnectionAlreadyScheduled) {
            log(LogIntent.WARNING) { BillingStrings.BILLING_CLIENT_RETRY_ALREADY_SCHEDULED }
        } else {
            log(LogIntent.WARNING) { BillingStrings.BILLING_CLIENT_RETRY.format(reconnectMilliseconds) }
            reconnectionAlreadyScheduled = true
            startConnection(reconnectMilliseconds)
            reconnectMilliseconds = min(
                reconnectMilliseconds * 2,
                RECONNECT_TIMER_MAX_TIME_MILLISECONDS,
            )
        }
    }

    override fun isConnected(): Boolean = billingClient?.isReady ?: false

    override fun showInAppMessagesIfNeeded(
        activity: Activity,
        inAppMessageTypes: List<InAppMessageType>,
        subscriptionStatusChange: () -> Unit,
    ) {
        if (inAppMessageTypes.isEmpty()) {
            errorLog { BillingStrings.BILLING_UNSPECIFIED_INAPP_MESSAGE_TYPES }
            return
        }

        val inAppMessageParamsBuilder = InAppMessageParams.newBuilder()
        for (inAppMessageType in inAppMessageTypes) {
            inAppMessageParamsBuilder.addInAppMessageCategoryToShow(inAppMessageType.inAppMessageCategoryId)
        }
        val inAppMessageParams = inAppMessageParamsBuilder.build()
        val weakActivity = WeakReference(activity)

        executeRequestOnUIThread { error ->
            if (error != null) {
                errorLog { BillingStrings.BILLING_CONNECTION_ERROR_INAPP_MESSAGES.format(error) }
                return@executeRequestOnUIThread
            }
            withConnectedClient {
                val activity = weakActivity.get() ?: run {
                    debugLog { "Activity is null, not showing Google Play in-app message." }
                    return@withConnectedClient
                }
                if (activity.isFinishing) {
                    debugLog { "Activity is finishing, not showing Google Play in-app message." }
                    return@withConnectedClient
                }
                if (activity.isDestroyed) {
                    debugLog { "Activity is destroyed, not showing Google Play in-app message." }
                    return@withConnectedClient
                }
                if (activity.window?.peekDecorView()?.windowToken == null) {
                    debugLog { "Activity is not attached to a window, not showing Google Play in-app message." }
                    return@withConnectedClient
                }
                try {
                    showInAppMessages(
                        activity,
                        inAppMessageParams,
                    ) { inAppMessageResult ->
                        when (val responseCode = inAppMessageResult.responseCode) {
                            InAppMessageResult.InAppMessageResponseCode.NO_ACTION_NEEDED -> {
                                verboseLog { BillingStrings.BILLING_INAPP_MESSAGE_NONE }
                            }

                            InAppMessageResult.InAppMessageResponseCode.SUBSCRIPTION_STATUS_UPDATED -> {
                                debugLog { BillingStrings.BILLING_INAPP_MESSAGE_UPDATE }
                                subscriptionStatusChange()
                            }

                            else -> errorLog {
                                BillingStrings.BILLING_INAPP_MESSAGE_UNEXPECTED_CODE.format(
                                    responseCode,
                                )
                            }
                        }
                    }
                } catch (@SuppressWarnings("TooGenericExceptionCaught") e: RuntimeException) {
                    errorLog(e) { BillingStrings.BILLING_INAPP_MESSAGE_SHOW_EXCEPTION.format(e) }
                }
            }
        }
    }

    override fun getStorefront(
        onSuccess: (String) -> Unit,
        onError: PurchasesErrorCallback,
    ) {
        verboseLog { BillingStrings.BILLING_INITIATE_GETTING_COUNTRY_CODE }
        GetBillingConfigUseCase(
            GetBillingConfigUseCaseParams(appInBackground),
            deviceCache = deviceCache,
            onReceive = { billingConfig -> onSuccess(billingConfig.countryCode) },
            onError = onError,
            withConnectedClient = ::withConnectedClient,
            executeRequestOnUIThread = ::executeRequestOnUIThread,
        ).run()
    }

    private fun withConnectedClient(receivingFunction: BillingClient.() -> Unit) {
        billingClient?.takeIf { it.isReady }?.let {
            it.receivingFunction()
        } ?: log(LogIntent.GOOGLE_WARNING) { BillingStrings.BILLING_CLIENT_DISCONNECTED.format(getStackTrace()) }
    }

    private fun getStackTrace(): String {
        val stringWriter = StringWriter()
        val printWriter = PrintWriter(stringWriter)
        Throwable().printStackTrace(printWriter)
        return stringWriter.toString()
    }

    private fun getStoreTransaction(
        purchase: Purchase,
        completion: (storeTxn: StoreTransaction) -> Unit,
    ) {
        log(LogIntent.DEBUG) {
            BillingStrings.BILLING_WRAPPER_PURCHASES_UPDATED
                .format(purchase.toHumanReadableDescription())
        }

        synchronized(this@BillingWrapper) {
            val context = purchaseContext[purchase.firstProductId]
            context?.productType?.let { productType ->
                completion(
                    purchase.toStoreTransaction(context),
                )
                return
            }

            getPurchaseType(purchase.purchaseToken) { type ->
                completion(
                    purchase.toStoreTransaction(type),
                )
            }
        }
    }

    private fun trackProductDetailsNotSupportedIfNeeded() {
        if (diagnosticsTrackerIfEnabled == null) return
        val billingResult = billingClient?.isFeatureSupported(BillingClient.FeatureType.PRODUCT_DETAILS)
        if (
            billingResult != null &&
            billingResult.responseCode == BillingClient.BillingResponseCode.FEATURE_NOT_SUPPORTED
        ) {
            diagnosticsTrackerIfEnabled.trackProductDetailsNotSupported(
                billingResult.responseCode,
                billingResult.debugMessage,
            )
        }
    }

    private fun trackPurchaseStartIfNeeded(
        googlePurchasingData: GooglePurchasingData,
        oldProductId: String?,
    ) {
        if (diagnosticsTrackerIfEnabled == null) return
        val subscriptionPurchasingData = googlePurchasingData as? GooglePurchasingData.Subscription
        val subscriptionOfferChosenPricingPhaseList = subscriptionPurchasingData
            ?.productDetails
            ?.subscriptionOfferDetails
            ?.first {
                it.offerToken == subscriptionPurchasingData.token
            }
            ?.pricingPhases
            ?.pricingPhaseList
        val hasIntroTrial = subscriptionOfferChosenPricingPhaseList?.any { it.priceAmountMicros == 0L }
        val hasIntroPrice = subscriptionOfferChosenPricingPhaseList
            ?.dropLast(1) // drop the last pricing phase, which is the base price
            ?.any { it.priceAmountMicros > 0L }
        diagnosticsTrackerIfEnabled.trackGooglePurchaseStarted(
            productId = googlePurchasingData.productId,
            oldProductId = oldProductId,
            hasIntroTrial = hasIntroTrial,
            hasIntroPrice = hasIntroPrice,
        )
    }

    private fun trackPurchaseUpdateReceivedIfNeeded(billingResult: BillingResult, purchases: List<Purchase>?) {
        if (diagnosticsTrackerIfEnabled == null) return
        diagnosticsTrackerIfEnabled.trackGooglePurchaseUpdateReceived(
            productIds = purchases?.flatMap { it.products },
            purchaseStatuses = purchases?.map { it.purchaseState.toRevenueCatPurchaseState().name },
            billingResponseCode = billingResult.responseCode,
            billingDebugMessage = billingResult.debugMessage,
        )
    }

    private fun buildPurchaseParams(
        purchaseInfo: GooglePurchasingData,
        replaceProductInfo: ReplaceProductInfo?,
        appUserID: String,
        isPersonalizedPrice: Boolean?,
    ): Result<BillingFlowParams, PurchasesError> {
        return when (purchaseInfo) {
            is GooglePurchasingData.InAppProduct -> {
                buildOneTimePurchaseParams(purchaseInfo, appUserID, isPersonalizedPrice)
            }

            is GooglePurchasingData.Subscription -> {
                buildSubscriptionPurchaseParams(purchaseInfo, replaceProductInfo, appUserID, isPersonalizedPrice)
            }
        }
    }

    private fun buildOneTimePurchaseParams(
        purchaseInfo: GooglePurchasingData.InAppProduct,
        appUserID: String,
        isPersonalizedPrice: Boolean?,
    ): Result<BillingFlowParams, PurchasesError> {
        val productDetailsParamsList = BillingFlowParams.ProductDetailsParams.newBuilder().apply {
            setProductDetails(purchaseInfo.productDetails)
        }.build()

        try {
            return Result.Success(
                BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(listOf(productDetailsParamsList))
                    .setObfuscatedAccountId(appUserID.sha256())
                    .apply {
                        isPersonalizedPrice?.let {
                            setIsOfferPersonalized(it)
                        }
                    }
                    .build(),
            )
        } catch (e: NoClassDefFoundError) {
            // Billing Client 7 may throw NoClassDefFoundError if core library desugaring is not enabled when building
            // a BillingFlowParams in some devices because the library started using Java 8 types.
            // This was fixed in Billing Client 8.
            throw NoCoreLibraryDesugaringException(e)
        }
    }

    private fun buildSubscriptionPurchaseParams(
        purchaseInfo: GooglePurchasingData.Subscription,
        replaceProductInfo: ReplaceProductInfo?,
        appUserID: String,
        isPersonalizedPrice: Boolean?,
    ): Result<BillingFlowParams, PurchasesError> {
        val productDetailsParamsList = buildSubscriptionProductDetailsParams(purchaseInfo = purchaseInfo)

        try {
            return Result.Success(
                BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(productDetailsParamsList)
                    .apply {
                        // only setObfuscatedAccountId for non-upgrade/downgrades until google issue is fixed:
                        // https://issuetracker.google.com/issues/155005449
                        replaceProductInfo?.let {
                            setUpgradeInfo(it)

                            // Allow setting ObfuscatedAccountID in product changes
                            // only when explicitly opted in via DangerousSettings
                            if (applyObfuscatedAccountIdToSubscriptionChanges) {
                                setObfuscatedAccountId(appUserID.sha256())
                            }
                        } ?: setObfuscatedAccountId(appUserID.sha256())

                        isPersonalizedPrice?.let {
                            setIsOfferPersonalized(it)
                        }
                    }
                    .build(),
            )
        } catch (e: NoClassDefFoundError) {
            // Billing Client 7 may throw NoClassDefFoundError if core library desugaring is not enabled when building
            // a BillingFlowParams in some devices because the library started using Java 8 types.
            // This was fixed in Billing Client 8.
            throw NoCoreLibraryDesugaringException(e)
        }
    }

    @OptIn(ExperimentalPreviewRevenueCatPurchasesAPI::class)
    private fun buildSubscriptionProductDetailsParams(
        purchaseInfo: GooglePurchasingData.Subscription,
    ): List<BillingFlowParams.ProductDetailsParams> {
        fun buildProductDetailParams(subscription: Subscription): BillingFlowParams.ProductDetailsParams {
            return BillingFlowParams.ProductDetailsParams.newBuilder().apply {
                setOfferToken(subscription.token)
                setProductDetails(subscription.productDetails)
            }.build()
        }

        val productDetailsParamsList: MutableList<ProductDetailsParams> = ArrayList()
        productDetailsParamsList.add(buildProductDetailParams(subscription = purchaseInfo))

        purchaseInfo.addOnProducts?.let { addOnProducts ->
            val addOnSubscriptionProductDetailsParams = addOnProducts
                .filterIsInstance<GooglePurchasingData.Subscription>()
                .map { subscriptionPurchasingData ->
                    buildProductDetailParams(
                        subscription = subscriptionPurchasingData,
                    )
                }

            productDetailsParamsList.addAll(addOnSubscriptionProductDetailsParams)
        }

        return productDetailsParamsList
    }

    @Synchronized
    private fun sendErrorsToAllPendingRequests(error: PurchasesError) {
        while (true) {
            serviceRequests.poll()?.let { (serviceRequest, _) ->
                mainHandler.post {
                    serviceRequest(error)
                }
            } ?: break
        }
    }
}
